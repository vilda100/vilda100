-- This SQL would be executed to set up the shared challenges functionality
-- Create shared_challenges table to track shared challenges
CREATE TABLE shared_challenges (
  id SERIAL PRIMARY KEY,
  challenge_id INTEGER NOT NULL,
  creator_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  share_code TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  difficulty TEXT,
  category TEXT,
  times_imported INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create index for faster lookups by share_code
CREATE INDEX shared_challenges_share_code_idx ON shared_challenges(share_code);

-- Create index for faster lookups by creator_id
CREATE INDEX shared_challenges_creator_id_idx ON shared_challenges(creator_id);

-- Create imported_challenges table to track which challenges users have imported
CREATE TABLE imported_challenges (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  shared_challenge_id INTEGER NOT NULL REFERENCES shared_challenges(id) ON DELETE CASCADE,
  custom_challenge_id INTEGER REFERENCES custom_challenges(id) ON DELETE SET NULL,
  imported_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, shared_challenge_id)
);

-- Create index for faster lookups by user_id
CREATE INDEX imported_challenges_user_id_idx ON imported_challenges(user_id);
