-- Create friend_groups table
CREATE TABLE IF NOT EXISTS friend_groups (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create group_members table to track members in each group
CREATE TABLE IF NOT EXISTS group_members (
  id SERIAL PRIMARY KEY,
  group_id INTEGER NOT NULL REFERENCES friend_groups(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member', -- 'admin' or 'member'
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(group_id, user_id)
);

-- Create group_challenges table for challenges specific to a group
CREATE TABLE IF NOT EXISTS group_challenges (
  id SERIAL PRIMARY KEY,
  group_id INTEGER NOT NULL REFERENCES friend_groups(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  difficulty TEXT,
  category TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create group_bingo_cards table to track bingo cards for group members
CREATE TABLE IF NOT EXISTS group_bingo_cards (
  id SERIAL PRIMARY KEY,
  group_id INTEGER NOT NULL REFERENCES friend_groups(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  card_data JSONB NOT NULL,
  completed_challenges INTEGER[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(group_id, user_id)
);

-- Create group_submissions table for challenge submissions within a group
CREATE TABLE IF NOT EXISTS group_submissions (
  id SERIAL PRIMARY KEY,
  group_id INTEGER NOT NULL REFERENCES friend_groups(id) ON DELETE CASCADE,
  challenge_id INTEGER NOT NULL,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  photo_url TEXT NOT NULL,
  status TEXT DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create submission_votes table for voting on submissions
CREATE TABLE IF NOT EXISTS submission_votes (
  id SERIAL PRIMARY KEY,
  submission_id INTEGER NOT NULL REFERENCES group_submissions(id) ON DELETE CASCADE,
  voter_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  vote BOOLEAN NOT NULL, -- true = approve, false = reject
  comment TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(submission_id, voter_id)
);

-- Create group_bingos table to track completed bingos
CREATE TABLE IF NOT EXISTS group_bingos (
  id SERIAL PRIMARY KEY,
  group_id INTEGER NOT NULL REFERENCES friend_groups(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  card_id INTEGER NOT NULL REFERENCES group_bingo_cards(id) ON DELETE CASCADE,
  bingo_type TEXT NOT NULL, -- 'row', 'column', 'diagonal'
  bingo_index INTEGER NOT NULL, -- index of the row/column/diagonal
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Add RLS policies
ALTER TABLE friend_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_bingo_cards ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE submission_votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_bingos ENABLE ROW LEVEL SECURITY;

-- Friend groups policies
CREATE POLICY "Friend groups are viewable by members"
  ON friend_groups FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM group_members
      WHERE group_members.group_id = friend_groups.id
      AND group_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create friend groups"
  ON friend_groups FOR INSERT
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Group admins can update their groups"
  ON friend_groups FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM group_members
      WHERE group_members.group_id = friend_groups.id
      AND group_members.user_id = auth.uid()
      AND group_members.role = 'admin'
    )
  );

CREATE POLICY "Group admins can delete their groups"
  ON friend_groups FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM group_members
      WHERE group_members.group_id = friend_groups.id
      AND group_members.user_id = auth.uid()
      AND group_members.role = 'admin'
    )
  );

-- Group members policies
CREATE POLICY "Group members are viewable by other members"
  ON group_members FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM group_members AS gm
      WHERE gm.group_id = group_members.group_id
      AND gm.user_id = auth.uid()
    )
  );

CREATE POLICY "Group admins can add members"
  ON group_members FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM group_members
      WHERE group_members.group_id = group_id
      AND group_members.user_id = auth.uid()
      AND group_members.role = 'admin'
    ) OR (
      -- Allow users to add themselves when creating a group
      auth.uid() = user_id AND
      EXISTS (
        SELECT 1 FROM friend_groups
        WHERE friend_groups.id = group_id
        AND friend_groups.created_by = auth.uid()
      )
    )
  );

-- Add more policies for other tables...
