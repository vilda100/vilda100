-- Create game_sessions table to manage multiplayer games
CREATE TABLE game_sessions (
  id SERIAL PRIMARY KEY,
  creator_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  invite_code TEXT NOT NULL UNIQUE,
  is_active BOOLEAN DEFAULT true,
  max_players INTEGER DEFAULT 10,
  end_time TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create index for faster lookups by invite_code
CREATE INDEX game_sessions_invite_code_idx ON game_sessions(invite_code);

-- Create index for faster lookups by creator_id
CREATE INDEX game_sessions_creator_id_idx ON game_sessions(creator_id);

-- Create session_players table to track players in each game session
CREATE TABLE session_players (
  id SERIAL PRIMARY KEY,
  session_id INTEGER NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  score INTEGER DEFAULT 0,
  has_bingo BOOLEAN DEFAULT false,
  card_id INTEGER REFERENCES bingo_cards(id) ON DELETE SET NULL,
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  last_active TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(session_id, user_id)
);

-- Create index for faster lookups by session_id
CREATE INDEX session_players_session_id_idx ON session_players(session_id);

-- Create index for faster lookups by user_id
CREATE INDEX session_players_user_id_idx ON session_players(user_id);

-- Create session_messages table for in-game chat
CREATE TABLE session_messages (
  id SERIAL PRIMARY KEY,
  session_id INTEGER NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create index for faster lookups by session_id
CREATE INDEX session_messages_session_id_idx ON session_messages(session_id);

-- Create session_events table to track game events
CREATE TABLE session_events (
  id SERIAL PRIMARY KEY,
  session_id INTEGER NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  event_type TEXT NOT NULL,
  event_data JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create index for faster lookups by session_id
CREATE INDEX session_events_session_id_idx ON session_events(session_id);

-- Add RLS policies for game_sessions
ALTER TABLE game_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public game_sessions are viewable by all users"
  ON game_sessions FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own game_sessions"
  ON game_sessions FOR INSERT
  WITH CHECK (auth.uid() = creator_id);

CREATE POLICY "Users can update their own game_sessions"
  ON game_sessions FOR UPDATE
  USING (auth.uid() = creator_id);

CREATE POLICY "Users can delete their own game_sessions"
  ON game_sessions FOR DELETE
  USING (auth.uid() = creator_id);

-- Add RLS policies for session_players
ALTER TABLE session_players ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Session players are viewable by all users"
  ON session_players FOR SELECT
  USING (true);

CREATE POLICY "Users can insert themselves as players"
  ON session_players FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own player data"
  ON session_players FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete themselves from sessions"
  ON session_players FOR DELETE
  USING (auth.uid() = user_id);

-- Add RLS policies for session_messages
ALTER TABLE session_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Session messages are viewable by session participants"
  ON session_messages FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM session_players
    WHERE session_players.session_id = session_messages.session_id
    AND session_players.user_id = auth.uid()
  ));

CREATE POLICY "Users can insert their own messages"
  ON session_messages FOR INSERT
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM session_players
      WHERE session_players.session_id = session_messages.session_id
      AND session_players.user_id = auth.uid()
    )
  );

-- Add RLS policies for session_events
ALTER TABLE session_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Session events are viewable by session participants"
  ON session_events FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM session_players
    WHERE session_players.session_id = session_events.session_id
    AND session_players.user_id = auth.uid()
  ));

CREATE POLICY "Users can insert their own events"
  ON session_events FOR INSERT
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM session_players
      WHERE session_players.session_id = session_events.session_id
      AND session_players.user_id = auth.uid()
    )
  );
