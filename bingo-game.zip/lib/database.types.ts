export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      challenges: {
        Row: {
          id: number
          title: string
          description: string
          difficulty: string
          category: string
          created_at: string
        }
        Insert: {
          id?: number
          title: string
          description?: string
          difficulty?: string
          category?: string
          created_at?: string
        }
        Update: {
          id?: number
          title?: string
          description?: string
          difficulty?: string
          category?: string
          created_at?: string
        }
      }
      custom_challenges: {
        Row: {
          id: number
          user_id: string
          title: string
          description: string
          difficulty: string
          category: string
          created_at: string
        }
        Insert: {
          id?: number
          user_id: string
          title: string
          description?: string
          difficulty?: string
          category?: string
          created_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          title?: string
          description?: string
          difficulty?: string
          category?: string
          created_at?: string
        }
      }
      submissions: {
        Row: {
          id: number
          user_id: string
          challenge_id: number
          photo_url: string
          status: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          user_id: string
          challenge_id: number
          photo_url: string
          status?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          challenge_id?: number
          photo_url?: string
          status?: string
          created_at?: string
          updated_at?: string
        }
      }
      bingo_cards: {
        Row: {
          id: number
          user_id: string
          card_data: Json
          completed_challenges: number[]
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          user_id: string
          card_data: Json
          completed_challenges?: number[]
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          card_data?: Json
          completed_challenges?: number[]
          created_at?: string
          updated_at?: string
        }
      }
      profiles: {
        Row: {
          id: string
          username: string
          avatar_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          username: string
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          username?: string
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}
