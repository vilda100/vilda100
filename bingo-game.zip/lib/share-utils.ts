import { nanoid } from "nanoid"

// Generate a unique share code
export const generateShareCode = (): string => {
  // Generate a short, URL-friendly unique ID
  return nanoid(10)
}

// Format a share URL
export const formatShareUrl = (baseUrl: string, code: string): string => {
  return `${baseUrl}/import/${code}`
}
