import { v4 as uuidv4 } from "uuid"

// Generate a unique guest ID
export const generateGuestId = (): string => {
  return `guest_${uuidv4()}`
}

// Save guest ID to localStorage
export const saveGuestId = (guestId: string): void => {
  localStorage.setItem("guestId", guestId)
}

// Get guest ID from localStorage
export const getGuestId = (): string | null => {
  if (typeof window === "undefined") return null
  return localStorage.getItem("guestId")
}

// Check if user is a guest
export const isGuest = (): boolean => {
  return !!getGuestId()
}

// Clear guest data when converting to registered user
export const clearGuestData = (): void => {
  localStorage.removeItem("guestId")
  localStorage.removeItem("guestCard")
  localStorage.removeItem("guestSubmissions")
}

// Save guest bingo card to localStorage
export const saveGuestCard = (cardData: any): void => {
  localStorage.setItem("guestCard", JSON.stringify(cardData))
}

// Get guest bingo card from localStorage
export const getGuestCard = (): any => {
  if (typeof window === "undefined") return null
  const card = localStorage.getItem("guestCard")
  return card ? JSON.parse(card) : null
}

// Save guest submission to localStorage
export const saveGuestSubmission = (submission: any): void => {
  const submissions = getGuestSubmissions() || []
  submissions.push(submission)
  localStorage.setItem("guestSubmissions", JSON.stringify(submissions))
}

// Get guest submissions from localStorage
export const getGuestSubmissions = (): any[] => {
  if (typeof window === "undefined") return []
  const submissions = localStorage.getItem("guestSubmissions")
  return submissions ? JSON.parse(submissions) : []
}

// Update guest completed challenges
export const updateGuestCompletedChallenges = (challengeId: number): void => {
  const card = getGuestCard()
  if (!card) return

  const completedChallenges = card.completed_challenges || []
  if (!completedChallenges.includes(challengeId)) {
    completedChallenges.push(challengeId)
    card.completed_challenges = completedChallenges
    saveGuestCard(card)
  }
}
