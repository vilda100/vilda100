export interface Challenge {
  id: number
  title: string
  description: string
  difficulty: string
  category: string
  created_at: string
}

export interface CustomChallenge {
  id: number
  user_id: string
  title: string
  description: string
  difficulty: string
  category: string
  created_at: string
}

export interface Submission {
  id: number
  user_id: string
  challenge_id: number
  photo_url: string
  status: "pending" | "approved" | "rejected"
  created_at: string
  updated_at: string
}

export interface BingoCardType {
  id: number
  user_id: string
  card_data: number[][]
  completed_challenges: number[]
  created_at: string
  updated_at: string
}

export interface Profile {
  id: string
  username: string
  avatar_url: string | null
  created_at: string
  updated_at: string
}
