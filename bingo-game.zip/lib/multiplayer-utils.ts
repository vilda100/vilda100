import { nanoid } from "nanoid"

// Generate a unique invite code for multiplayer games
export const generateInviteCode = (): string => {
  // Generate a short, URL-friendly unique ID
  return nanoid(8).toUpperCase()
}

// Format a player's score for display
export const formatPlayerScore = (score: number, totalChallenges = 25): string => {
  return `${score}/${totalChallenges}`
}

// Check if a player has won (has bingo)
export const checkForBingo = (cardData: number[][], completedChallenges: number[]): boolean => {
  if (!cardData.length || completedChallenges.length < 5) return false

  // Check rows
  for (let row = 0; row < 5; row++) {
    if (cardData[row].every((challengeId) => completedChallenges.includes(challengeId))) {
      return true
    }
  }

  // Check columns
  for (let col = 0; col < 5; col++) {
    const column = cardData.map((row) => row[col])
    if (column.every((challengeId) => completedChallenges.includes(challengeId))) {
      return true
    }
  }

  // Check diagonals
  const diagonal1 = [cardData[0][0], cardData[1][1], cardData[2][2], cardData[3][3], cardData[4][4]]
  const diagonal2 = [cardData[0][4], cardData[1][3], cardData[2][2], cardData[3][1], cardData[4][0]]

  if (
    diagonal1.every((challengeId) => completedChallenges.includes(challengeId)) ||
    diagonal2.every((challengeId) => completedChallenges.includes(challengeId))
  ) {
    return true
  }

  return false
}
