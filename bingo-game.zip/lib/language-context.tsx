"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { englishTranslations, czechTranslations } from "./translations"

type Language = "en" | "cs"

type LanguageContextType = {
  language: Language
  t: (key: string) => string
  toggleLanguage: () => void
  isCzechMode: boolean
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")

  // Load language preference from localStorage on mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem("language") as Language
    if (savedLanguage) {
      setLanguage(savedLanguage)
    }
  }, [])

  // Save language preference to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("language", language)
  }, [language])

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "en" ? "cs" : "en"))
  }

  // Get translation function
  const t = (key: string): string => {
    const translations = language === "en" ? englishTranslations : czechTranslations
    return translations[key as keyof typeof translations] || key
  }

  return (
    <LanguageContext.Provider value={{ language, t, toggleLanguage, isCzechMode: language === "cs" }}>
      {children}
    </LanguageContext.Provider>
  )
}

export const useLanguage = () => {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used inside LanguageProvider")
  }
  return context
}
