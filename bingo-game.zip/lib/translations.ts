// Czech translations for the application
export const czechTranslations = {
  // Navigation and headers
  photoChallengeBingo: "Fotografické Bingo Výzvy",
  playAsGuest: "Hrát jako host",
  createAccount: "Vytvořit účet",
  signIn: "Přihlásit se",
  signUp: "Registrovat se",
  signOut: "Odhlásit se",

  // Landing page
  tagline: "Splňte výzvy. Nahrajte fotky. Vyhrajte v Bingu!",
  description: "Zábavná hra, kde plníte výzvy z reálného světa a nahráváte fotky jako důkaz.",
  startPlaying: "Začít hrát",
  guestModeWarning: "Režim hosta ukládá váš postup pouze na tomto zařízení.",

  // How it works section
  howItWorks: "Jak to funguje",
  getYourBingoCard: "Získejte svou Bingo kartu",
  getYourBingoCardDesc: "Obdržíte kartu plnou zábavných fotografických výzev k splnění v reálném světě.",
  completeChallenges: "Splňte výzvy",
  completeChallengesDesc: "Pořiďte fotky, které odpovídají výzvám na vaší bingo kartě.",
  uploadProof: "Nahrajte důkaz",
  uploadProofDesc: "Nahrajte své fotky jako důkaz a označte výzvy jako splněné na své kartě.",

  // Why create account section
  whyCreateAccount: "Proč si vytvořit účet?",
  whyCreateAccountDesc: "Vytvoření účtu vám umožní ukládat váš postup, soutěžit s přáteli a odemykat úspěchy!",

  // Game page
  newCard: "Nová karta",
  youWon: "BINGO! Vyhráli jste!",

  // How to play card
  howToPlay: "Jak hrát",
  howToPlaySteps: [
    "Vyberte výzvu z vaší bingo karty",
    "Splňte výzvu v reálném životě",
    "Vyfoťte důkaz",
    "Nahrajte svou fotku pro označení výzvy jako splněné",
    "Dokončete řádek, sloupec nebo diagonálu pro výhru!",
  ],

  // Guest mode
  guestModeTitle: "Hrajete jako host",
  guestModeDesc: "Váš postup je uložen pouze na tomto zařízení.",
  createAccountToSave: "Vytvořte si účet pro trvalé uložení vašeho postupu",

  // Guest limitations
  guestModeLimitations: "Omezení režimu hosta",
  guestModeLimitationsItems: [
    "Váš postup je uložen pouze na tomto zařízení",
    "Fotky jsou uloženy dočasně",
    "Nemůžete soutěžit s ostatními hráči",
    "Postup může být ztracen při vymazání dat prohlížeče",
  ],
  createAccountToSaveProgress: "Vytvořte si účet pro uložení postupu",

  // Challenge detail
  back: "Zpět na Bingo kartu",
  yourSubmission: "Vaše řešení",
  challengeCompleted: "Výzva splněna",
  uploadPhoto: "Nahrajte fotku pro splnění této výzvy",
  noPhotoYet: "Zatím žádná fotka nenahrána",
  selectPhoto: "Vybrat fotku",
  changePhoto: "Změnit fotku",
  upload: "Nahrát",
  saving: "Ukládání...",

  // Difficulty levels
  easy: "Lehká",
  medium: "Střední",
  hard: "Těžká",

  // Progress
  challengesCompleted: "Splněné výzvy",
  recentSubmissions: "Nedávná řešení",
  noSubmissionsYet: "Zatím žádná řešení",

  // Statuses
  pending: "Čeká na schválení",
  approved: "Schváleno",
  rejected: "Zamítnuto",

  // Custom challenges
  customChallenges: "Vlastní výzvy",
  addNewChallenge: "Přidat novou výzvu",
  editChallenge: "Upravit výzvu",
  challengeTitle: "Název výzvy",
  challengeDescription: "Popis výzvy",
  difficulty: "Obtížnost",
  category: "Kategorie",
  cancel: "Zrušit",
  saveChanges: "Uložit změny",
  addChallenge: "Přidat výzvu",
  noDescription: "Bez popisu",
  noCustomChallengesYet: "Zatím nemáte žádné vlastní výzvy. Vytvořte si první výzvu pomocí tlačítka výše.",
  aboutCustomChallenges: "O vlastních výzvách",
  customChallengesDescription:
    "Vlastní výzvy vám umožňují vytvořit si personalizovanou bingo hru s vašimi vlastními nápady na fotografické výzvy.",
  customChallengesWillAppear:
    "Vaše vlastní výzvy se budou objevovat na vaší bingo kartě společně s předdefinovanými výzvami.",
  tipsForGoodChallenges: "Tipy pro dobré výzvy:",
  tipSpecific: "Buďte konkrétní a jasní v tom, co má být vyfoceno",
  tipDifficulty: "Vytvářejte výzvy různé obtížnosti",
  tipCategories: "Přemýšlejte o různých kategoriích (jídlo, příroda, architektura...)",
  tipCreative: "Buďte kreativní a zábavní",
  backToGame: "Zpět na hru",
  manageCustomChallenges: "Spravovat vlastní výzvy",
  createCustomChallenges: "Vytvořte si vlastní výzvy pro vaši bingo hru a přizpůsobte si ji podle svých představ.",
  challengeAdded: "Výzva přidána",
  challengeAddedDesc: "Vaše vlastní výzva byla úspěšně přidána.",
  errorAddingChallenge: "Chyba při přidávání výzvy",
  challengeUpdated: "Výzva aktualizována",
  challengeUpdatedDesc: "Vaše vlastní výzva byla úspěšně aktualizována.",
  errorUpdatingChallenge: "Chyba při aktualizaci výzvy",
  challengeDeleted: "Výzva smazána",
  challengeDeletedDesc: "Vaše vlastní výzva byla úspěšně smazána.",
  errorDeletingChallenge: "Chyba při mazání výzvy",
  confirmDeleteChallenge: "Opravdu chcete smazat tuto výzvu?",

  // Categories
  custom: "Vlastní",
  food: "Jídlo",
  drinks: "Nápoje",
  landmarks: "Památky",
  nature: "Příroda",
  people: "Lidé",
  animals: "Zvířata",
  architecture: "Architektura",
  art: "Umění",
  transportation: "Doprava",
  technology: "Technologie",
  sports: "Sport",
  everyday: "Každodenní",
  funny: "Vtipné",

  // Form placeholders
  challengeTitlePlaceholder: "Např. Vyfoť červené auto",
  challengeDescriptionPlaceholder: "Podrobnější popis výzvy, např. Najdi a vyfoť červené auto na parkovišti",
  selectDifficulty: "Vyberte obtížnost",
  selectCategory: "Vyberte kategorii",
  saving: "Ukládání...",

  // Challenge sharing
  shareYourChallenges: "Sdílejte své výzvy",
  shareChallenges: "Sdílet výzvy",
  selectChallengesToShare: "Vyberte výzvy ke sdílení",
  selectChallengesToShareDesc: "Vyberte výzvy, které chcete sdílet s ostatními hráči",
  shareSelectedChallenges: "Sdílet vybrané výzvy",
  challengeShared: "Výzva sdílena",
  challengeSharedDesc: "Odkaz ke sdílení byl vygenerován",
  errorSharingChallenge: "Chyba při sdílení výzvy",
  shareAnotherChallenge: "Sdílet další výzvu",
  openLink: "Otevřít odkaz",
  copied: "Zkopírováno",
  copiedToClipboard: "Odkaz byl zkopírován do schránky",
  sharing: "Sdílení...",
  yourSharedChallenges: "Vaše sdílené výzvy",
  imports: "importů",
  shared: "Sdíleno",
  shareCode: "Kód pro sdílení:",

  // About sharing
  aboutSharingChallenges: "O sdílení výzev",
  sharingChallengesDesc: "Sdílení výzev vám umožňuje sdílet vaše vlastní výzvy s přáteli a dalšími hráči.",
  whenYouShareDesc: "Když sdílíte výzvu, vytvoří se unikátní odkaz, který můžete poslat komukoliv.",
  othersCanImportDesc: "Ostatní hráči mohou importovat vaše výzvy do své hry a používat je ve svých bingo kartách.",
  howToShareChallenges: "Jak sdílet výzvy:",
  selectChallenges: "Vyberte výzvy, které chcete sdílet",
  clickShareButton: "Klikněte na tlačítko 'Sdílet vybrané výzvy'",
  copyAndShareLink: "Zkopírujte vygenerovaný odkaz a sdílejte ho s přáteli",

  // Import challenges
  importChallenge: "Importovat výzvu",
  importAChallenge: "Importovat výzvu",
  haveAShareCode: "Máte kód pro sdílení od přítele? Importujte jeho výzvu do své hry!",
  enterShareCode: "Zadejte kód pro sdílení",
  missingCode: "Chybí kód",
  pleaseEnterShareCode: "Zadejte kód pro sdílení",
  challengeImported: "Výzva importována",
  challengeImportedDesc: "Výzva byla úspěšně přidána do vašich vlastních výzev",
  errorImportingChallenge: "Chyba při importu výzvy",
  importing: "Importování...",
  importThisChallenge: "Importovat tuto výzvu",

  // About importing
  aboutImportingChallenges: "O importování výzev",
  importingChallengesDesc: "Importování výzev vám umožňuje přidat výzvy vytvořené jinými hráči do vaší hry.",
  importedChallengesDesc:
    "Importované výzvy se stanou součástí vašich vlastních výzev a můžete je používat ve svých bingo kartách.",
  afterImportingDesc: "Po importu můžete výzvu upravit podle svých představ.",
  whatHappensAfterImporting: "Co se stane po importu:",
  challengeAddedToCustom: "Výzva se přidá do vašich vlastních výzev",
  youCanEditOrDelete: "Můžete ji upravit nebo smazat",
  willAppearOnCards: "Bude se objevovat na vašich bingo kartách",
  creatorWillSee: "Tvůrce výzvy uvidí, že byla importována",

  // Creator info
  createdBy: "Vytvořil(a)",
  imported: "Importováno",
  times: "krát",

  // No challenges
  noCustomChallengesForSharing: "Zatím nemáte žádné vlastní výzvy. Vytvořte si výzvy, které můžete sdílet.",

  // For guest users
  createAccountToCreateCustom: "Pro vytváření vlastních výzev si prosím vytvořte účet.",

  // Share button
  share: "Sdílet",
  backToCustomChallenges: "Zpět na vlastní výzvy",
  forgotPassword: "Zapomenuté heslo?",
  resetPassword: "Obnovení hesla",
  setNewPassword: "Nastavení nového hesla",
  newPassword: "Nové heslo",
  confirmPassword: "Potvrzení hesla",
  passwordsDoNotMatch: "Hesla se neshodují",
  emailSent: "Email odeslán",
  passwordResetInstructions: "Pokyny k obnovení hesla byly odeslány na váš email",
  checkSpamFolder: "Pokud email neobdržíte do několika minut, zkontrolujte složku spam",
  sendInstructions: "Odeslat pokyny",
  backToSignIn: "Zpět na přihlášení",
  passwordReset: "Heslo obnoveno",
  passwordResetSuccess: "Vaše heslo bylo úspěšně obnoveno",
  rememberMe: "Zapamatovat si mě",
  continueWithGithub: "Pokračovat s GitHub",
  termsOfService: "Souhlasím s podmínkami použití a zásadami ochrany osobních údajů",
  passwordStrength: {
    veryWeak: "Velmi slabé",
    weak: "Slabé",
    medium: "Střední",
    strong: "Silné",
    veryStrong: "Velmi silné",
  },
  validation: {
    emailRequired: "Email je povinný",
    invalidEmail: "Neplatný formát emailu",
    passwordRequired: "Heslo je povinné",
    passwordLength: "Heslo musí mít alespoň 8 znaků",
    usernameRequired: "Uživatelské jméno je povinné",
    usernameLength: "Uživatelské jméno musí mít alespoň 3 znaky",
    termsRequired: "Musíte souhlasit s podmínkami",
  },

  // Social login
  continueWithGoogle: "Pokračovat s Google",
  continueWithFacebook: "Pokračovat s Facebook",
  continueWithTwitter: "Pokračovat s Twitter",
  socialLoginError: "Chyba při přihlášení přes sociální síť",
}

// English translations for the application
export const englishTranslations = {
  // Navigation and headers
  photoChallengeBingo: "Photo Challenge Bingo",
  playAsGuest: "Play as Guest",
  createAccount: "Create Account",
  signIn: "Sign In",
  signUp: "Sign Up",
  signOut: "Sign Out",

  // Landing page
  tagline: "Complete Challenges. Upload Photos. Win at Bingo!",
  description: "A fun photo scavenger hunt game where you complete real-world challenges and upload photos as proof.",
  startPlaying: "Start Playing Now",
  guestModeWarning: "Guest mode saves your progress only on this device.",

  // How it works section
  howItWorks: "How It Works",
  getYourBingoCard: "Get Your Bingo Card",
  getYourBingoCardDesc: "Receive a card filled with fun photo challenges to complete in the real world.",
  completeChallenges: "Complete Challenges",
  completeChallengesDesc: "Take photos that match the challenges on your bingo card.",
  uploadProof: "Upload Proof",
  uploadProofDesc: "Submit your photos as proof and mark challenges as complete on your card.",

  // Why create account section
  whyCreateAccount: "Why Create an Account?",
  whyCreateAccountDesc:
    "Creating an account lets you save your progress, compete with friends, and unlock achievements!",

  // Game page
  newCard: "New Card",
  youWon: "BINGO! You won!",

  // How to play card
  howToPlay: "How to Play",
  howToPlaySteps: [
    "Select a challenge from your bingo card",
    "Complete the challenge in real life",
    "Take a photo as proof",
    "Upload your photo to mark the challenge as complete",
    "Complete a row, column, or diagonal to win!",
  ],

  // Guest mode
  guestModeTitle: "You're playing as a guest",
  guestModeDesc: "Your progress is only saved on this device.",
  createAccountToSave: "Create an account to save your progress permanently",

  // Guest limitations
  guestModeLimitations: "Guest Mode Limitations",
  guestModeLimitationsItems: [
    "Your progress is only saved on this device",
    "Photos are stored temporarily",
    "You can't compete with other players",
    "Progress may be lost if you clear browser data",
  ],
  createAccountToSaveProgress: "Create Account to Save Progress",

  // Challenge detail
  back: "Back to Bingo Card",
  yourSubmission: "Your Submission",
  challengeCompleted: "Challenge completed",
  uploadPhoto: "Upload a photo to complete this challenge",
  noPhotoYet: "No photo uploaded yet",
  selectPhoto: "Select Photo",
  changePhoto: "Change Photo",
  upload: "Upload",
  saving: "Saving...",

  // Difficulty levels
  easy: "Easy",
  medium: "Medium",
  hard: "Hard",

  // Progress
  challengesCompleted: "Challenges Completed",
  recentSubmissions: "Recent Submissions:",
  noSubmissionsYet: "No submissions yet",

  // Statuses
  pending: "Pending",
  approved: "Approved",
  rejected: "Rejected",

  // Custom challenges
  customChallenges: "Custom Challenges",
  addNewChallenge: "Add New Challenge",
  editChallenge: "Edit Challenge",
  challengeTitle: "Challenge Title",
  challengeDescription: "Challenge Description",
  difficulty: "Difficulty",
  category: "Category",
  cancel: "Cancel",
  saveChanges: "Save Changes",
  addChallenge: "Add Challenge",
  noDescription: "No description",
  noCustomChallengesYet:
    "You don't have any custom challenges yet. Create your first challenge using the button above.",
  aboutCustomChallenges: "About Custom Challenges",
  customChallengesDescription:
    "Custom challenges allow you to create a personalized bingo game with your own photo challenge ideas.",
  customChallengesWillAppear:
    "Your custom challenges will appear on your bingo card along with the predefined challenges.",
  tipsForGoodChallenges: "Tips for good challenges:",
  tipSpecific: "Be specific and clear about what should be photographed",
  tipDifficulty: "Create challenges of varying difficulty",
  tipCategories: "Think about different categories (food, nature, architecture...)",
  tipCreative: "Be creative and fun",
  backToGame: "Back to Game",
  manageCustomChallenges: "Manage Custom Challenges",
  createCustomChallenges: "Create your own challenges for your bingo game and customize it to your liking.",
  challengeAdded: "Challenge added",
  challengeAddedDesc: "Your custom challenge has been added successfully.",
  errorAddingChallenge: "Error adding challenge",
  challengeUpdated: "Challenge updated",
  challengeUpdatedDesc: "Your custom challenge has been updated successfully.",
  errorUpdatingChallenge: "Error updating challenge",
  challengeDeleted: "Challenge deleted",
  challengeDeletedDesc: "Your custom challenge has been deleted successfully.",
  errorDeletingChallenge: "Error deleting challenge",
  confirmDeleteChallenge: "Are you sure you want to delete this challenge?",

  // Categories
  custom: "Custom",
  food: "Food",
  drinks: "Drinks",
  landmarks: "Landmarks",
  nature: "Nature",
  people: "People",
  animals: "Animals",
  architecture: "Architecture",
  art: "Art",
  transportation: "Transportation",
  technology: "Technology",
  sports: "Sports",
  everyday: "Everyday",
  funny: "Funny",

  // Form placeholders
  challengeTitlePlaceholder: "E.g., Take a photo of a red car",
  challengeDescriptionPlaceholder:
    "More detailed description, e.g., Find and take a photo of a red car in a parking lot",
  selectDifficulty: "Select difficulty",
  selectCategory: "Select category",
  saving: "Saving...",

  // Challenge sharing
  shareYourChallenges: "Share Your Challenges",
  shareChallenges: "Share Challenges",
  selectChallengesToShare: "Select Challenges to Share",
  selectChallengesToShareDesc: "Select challenges you want to share with other players",
  shareSelectedChallenges: "Share Selected Challenges",
  challengeShared: "Challenge Shared",
  challengeSharedDesc: "Share link has been generated",
  errorSharingChallenge: "Error sharing challenge",
  shareAnotherChallenge: "Share Another Challenge",
  openLink: "Open Link",
  copied: "Copied",
  copiedToClipboard: "Link has been copied to clipboard",
  sharing: "Sharing...",
  yourSharedChallenges: "Your Shared Challenges",
  imports: "imports",
  shared: "Shared",
  shareCode: "Share code:",

  // About sharing
  aboutSharingChallenges: "About Sharing Challenges",
  sharingChallengesDesc: "Challenge sharing allows you to share your custom challenges with friends and other players.",
  whenYouShareDesc: "When you share a challenge, a unique link is created that you can send to anyone.",
  othersCanImportDesc: "Other players can import your challenges into their game and use them in their bingo cards.",
  howToShareChallenges: "How to share challenges:",
  selectChallenges: "Select the challenges you want to share",
  clickShareButton: "Click the 'Share Selected Challenges' button",
  copyAndShareLink: "Copy the generated link and share it with friends",

  // Import challenges
  importChallenge: "Import Challenge",
  importAChallenge: "Import a Challenge",
  haveAShareCode: "Have a share code from a friend? Import their challenge into your game!",
  enterShareCode: "Enter share code",
  missingCode: "Missing code",
  pleaseEnterShareCode: "Please enter a share code",
  challengeImported: "Challenge imported",
  challengeImportedDesc: "Challenge has been successfully added to your custom challenges",
  errorImportingChallenge: "Error importing challenge",
  importing: "Importing...",
  importThisChallenge: "Import This Challenge",

  // About importing
  aboutImportingChallenges: "About Importing Challenges",
  importingChallengesDesc: "Importing challenges allows you to add challenges created by other players to your game.",
  importedChallengesDesc:
    "Imported challenges become part of your custom challenges and you can use them in your bingo cards.",
  afterImportingDesc: "After importing, you can edit the challenge to suit your preferences.",
  whatHappensAfterImporting: "What happens after importing:",
  challengeAddedToCustom: "The challenge is added to your custom challenges",
  youCanEditOrDelete: "You can edit or delete it",
  willAppearOnCards: "It will appear on your bingo cards",
  creatorWillSee: "The creator will see that it was imported",

  // Creator info
  createdBy: "Created by",
  imported: "Imported",
  times: "times",

  // No challenges
  noCustomChallengesForSharing: "You don't have any custom challenges yet. Create challenges that you can share.",

  // For guest users
  createAccountToCreateCustom: "Please create an account to create custom challenges.",

  // Share button
  share: "Share",
  backToCustomChallenges: "Back to Custom Challenges",
  forgotPassword: "Forgot password?",
  resetPassword: "Reset Password",
  setNewPassword: "Set New Password",
  newPassword: "New Password",
  confirmPassword: "Confirm Password",
  passwordsDoNotMatch: "Passwords do not match",
  emailSent: "Email Sent",
  passwordResetInstructions: "Password reset instructions have been sent to your email",
  checkSpamFolder: "If you don't receive an email within a few minutes, check your spam folder",
  sendInstructions: "Send Instructions",
  backToSignIn: "Back to Sign In",
  passwordReset: "Password Reset",
  passwordResetSuccess: "Your password has been successfully reset",
  rememberMe: "Remember me",
  continueWithGithub: "Continue with GitHub",
  termsOfService: "I agree to the terms of service and privacy policy",
  passwordStrength: {
    veryWeak: "Very weak",
    weak: "Weak",
    medium: "Medium",
    strong: "Strong",
    veryStrong: "Very strong",
  },
  validation: {
    emailRequired: "Email is required",
    invalidEmail: "Invalid email format",
    passwordRequired: "Password is required",
    passwordLength: "Password must be at least 8 characters",
    usernameRequired: "Username is required",
    usernameLength: "Username must be at least 3 characters",
    termsRequired: "You must accept the terms",
  },

  // Social login
  continueWithGoogle: "Continue with Google",
  continueWithFacebook: "Continue with Facebook",
  continueWithTwitter: "Continue with Twitter",
  socialLoginError: "Error signing in with social provider",
}

// Czech challenges
export const czechChallenges = [
  {
    title: "Vyfoť tradiční český trdelník",
    description: "Najdi a vyfoť tradiční český trdelník v pekárně nebo na trhu",
    difficulty: "easy",
    category: "food",
  },
  {
    title: "Vyfoť se s českým pivem",
    description: "Vyfoť se s půllitrem českého piva v hospodě nebo restauraci",
    difficulty: "easy",
    category: "drinks",
  },
  {
    title: "Najdi sochu sv. Václava",
    description: "Vyfoť sochu sv. Václava nebo jiného českého patrona",
    difficulty: "medium",
    category: "landmarks",
  },
  {
    title: "Vyfoť Pražský hrad",
    description: "Pořiď fotografii Pražského hradu z jakéhokoliv úhlu",
    difficulty: "medium",
    category: "landmarks",
  },
  {
    title: "Najdi českou vlajku",
    description: "Vyfoť českou vlajku vlající na budově nebo stožáru",
    difficulty: "easy",
    category: "symbols",
  },
  {
    title: "Vyfoť Karlův most",
    description: "Pořiď fotografii Karlova mostu nebo jedné z jeho soch",
    difficulty: "medium",
    category: "landmarks",
  },
  {
    title: "Najdi tradiční českou hospodu",
    description: "Vyfoť vývěsní štít nebo vchod do tradiční české hospody",
    difficulty: "easy",
    category: "culture",
  },
  {
    title: "Vyfoť české koruny",
    description: "Vyfoť české mince nebo bankovky",
    difficulty: "easy",
    category: "everyday",
  },
  {
    title: "Najdi orloj",
    description: "Vyfoť Pražský orloj nebo jiné historické hodiny",
    difficulty: "medium",
    category: "landmarks",
  },
  {
    title: "Vyfoť tradiční český kroj",
    description: "Najdi a vyfoť tradiční český lidový kroj",
    difficulty: "hard",
    category: "culture",
  },
  {
    title: "Najdi české loutkové divadlo",
    description: "Vyfoť loutkové divadlo nebo tradiční české loutky",
    difficulty: "medium",
    category: "culture",
  },
  {
    title: "Vyfoť Staroměstské náměstí",
    description: "Pořiď fotografii Staroměstského náměstí v Praze",
    difficulty: "medium",
    category: "landmarks",
  },
  {
    title: "Najdi český křišťál",
    description: "Vyfoť výrobky z českého křišťálu v obchodě nebo výloze",
    difficulty: "medium",
    category: "crafts",
  },
  {
    title: "Vyfoť tramvaj",
    description: "Vyfoť českou tramvaj v provozu",
    difficulty: "easy",
    category: "transportation",
  },
  {
    title: "Najdi knihu od českého autora",
    description: "Vyfoť knihu od Karla Čapka, Milana Kundery nebo jiného českého spisovatele",
    difficulty: "medium",
    category: "culture",
  },
  {
    title: "Vyfoť české lázeňské oplatky",
    description: "Najdi a vyfoť tradiční české lázeňské oplatky",
    difficulty: "medium",
    category: "food",
  },
  {
    title: "Najdi Žižkovskou věž",
    description: "Vyfoť charakteristickou Žižkovskou televizní věž",
    difficulty: "medium",
    category: "landmarks",
  },
  {
    title: "Vyfoť české sklo",
    description: "Najdi a vyfoť tradiční české sklo nebo skleněné výrobky",
    difficulty: "medium",
    category: "crafts",
  },
  {
    title: "Najdi českou kapličku",
    description: "Vyfoť malou českou kapličku nebo kostelík na venkově",
    difficulty: "hard",
    category: "architecture",
  },
  {
    title: "Vyfoť český granát",
    description: "Najdi a vyfoť šperky s českým granátem",
    difficulty: "medium",
    category: "crafts",
  },
  {
    title: "Najdi českou vlakovou stanici",
    description: "Vyfoť nádraží nebo vlakovou stanici s českým názvem",
    difficulty: "easy",
    category: "transportation",
  },
  {
    title: "Vyfoť české pivo v lahvi",
    description: "Najdi a vyfoť lahev českého piva (Pilsner Urquell, Budvar, atd.)",
    difficulty: "easy",
    category: "drinks",
  },
  {
    title: "Najdi českou poštovní schránku",
    description: "Vyfoť charakteristickou českou poštovní schránku",
    difficulty: "easy",
    category: "everyday",
  },
  {
    title: "Vyfoť český perník",
    description: "Najdi a vyfoť tradiční český perník",
    difficulty: "medium",
    category: "food",
  },
  {
    title: "Najdi českou lidovou architekturu",
    description: "Vyfoť tradiční českou chalupu nebo lidovou architekturu",
    difficulty: "hard",
    category: "architecture",
  },
]
