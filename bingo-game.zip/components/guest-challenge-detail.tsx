"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Camera, CheckCircle, LogIn } from "lucide-react"
import GuestBanner from "./guest-banner"
import GuestPhotoUpload from "./guest-photo-upload"
import { getGuestId, getGuestSubmissions, saveGuestSubmission, updateGuestCompletedChallenges } from "@/lib/guest-utils"
import type { Challenge } from "@/lib/types"

interface GuestChallengeDetailProps {
  challenge: Challenge
}

export default function GuestChallengeDetail({ challenge }: GuestChallengeDetailProps) {
  const router = useRouter()
  const { toast } = useToast()
  const [uploading, setUploading] = useState(false)
  const [photoUrl, setPhotoUrl] = useState<string | null>(null)
  const [submission, setSubmission] = useState<any | null>(null)

  // Load existing submission if any
  useEffect(() => {
    const submissions = getGuestSubmissions()
    const existingSubmission = submissions.find((sub) => sub.challenge_id === challenge.id)
    if (existingSubmission) {
      setSubmission(existingSubmission)
      setPhotoUrl(existingSubmission.photo_url)
    }
  }, [challenge.id])

  const handlePhotoUpload = async (file: File) => {
    if (!file) return

    setUploading(true)

    try {
      // For guest users, we'll create a local object URL
      const objectUrl = URL.createObjectURL(file)

      // Create a submission record in localStorage
      const guestId = getGuestId()
      const newSubmission = {
        id: Date.now(), // Use timestamp as ID
        user_id: guestId,
        challenge_id: challenge.id,
        photo_url: objectUrl,
        status: "approved", // Auto-approve for guest users
        created_at: new Date().toISOString(),
      }

      // Save submission to localStorage
      saveGuestSubmission(newSubmission)

      // Update completed challenges
      updateGuestCompletedChallenges(challenge.id)

      setPhotoUrl(objectUrl)
      setSubmission(newSubmission)

      toast({
        title: "Photo saved",
        description: "Your submission has been saved locally.",
      })
    } catch (error: any) {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <GuestBanner />

      <Button variant="ghost" onClick={() => router.push("/game")} className="mb-6 flex items-center gap-2">
        <ArrowLeft className="h-4 w-4" />
        Back to Bingo Card
      </Button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>{challenge.title}</CardTitle>
            <CardDescription>
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary mr-2">
                {challenge.difficulty}
              </span>
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary/10 text-secondary">
                {challenge.category}
              </span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p>{challenge.description}</p>
          </CardContent>
          <CardFooter>
            <div className="text-sm text-muted-foreground">
              Complete this challenge by taking a photo that matches the description.
            </div>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Your Submission</CardTitle>
            <CardDescription>
              {submission ? (
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Challenge completed</span>
                </div>
              ) : (
                <span>Upload a photo to complete this challenge</span>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {photoUrl ? (
              <div className="relative aspect-video w-full overflow-hidden rounded-md">
                <img
                  src={photoUrl || "/placeholder.svg"}
                  alt="Challenge submission"
                  className="object-cover w-full h-full"
                />
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 bg-muted rounded-md">
                <Camera className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No photo uploaded yet</p>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            <GuestPhotoUpload onUpload={handlePhotoUpload} uploading={uploading} />

            <div className="w-full pt-4 border-t">
              <p className="text-sm text-muted-foreground mb-4">
                As a guest, your photos are only stored on this device. Create an account to save your progress
                permanently.
              </p>
              <Link href="/auth/sign-up">
                <Button variant="outline" className="w-full flex items-center gap-2">
                  <LogIn className="h-4 w-4" />
                  Create Account
                </Button>
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
