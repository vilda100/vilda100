"use client"

import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Camera, Check } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import type { Challenge } from "@/lib/types"

interface BingoCardProps {
  cardData: number[][]
  challenges: Challenge[]
  completedChallenges: number[]
  hasSubmission: (challengeId: number) => boolean
}

export default function BingoCard({ cardData, challenges, completedChallenges, hasSubmission }: BingoCardProps) {
  const { t } = useLanguage()

  // Get challenge by ID
  const getChallengeById = (id: number) => {
    return challenges.find((challenge) => challenge.id === id)
  }

  // Check if a challenge is completed
  const isCompleted = (challengeId: number) => {
    return completedChallenges.includes(challengeId)
  }

  if (!cardData.length) {
    return (
      <div className="flex items-center justify-center h-96 bg-muted rounded-lg">
        <p className="text-muted-foreground">Loading your bingo card...</p>
      </div>
    )
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div className="grid grid-cols-5 gap-2">
          {["B", "I", "N", "G", "O"].map((letter) => (
            <div
              key={letter}
              className="flex items-center justify-center h-12 bg-primary text-primary-foreground font-bold text-xl rounded-md"
            >
              {letter}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-5 gap-2 mt-2">
          {cardData.map((row, rowIndex) =>
            row.map((challengeId, colIndex) => {
              const challenge = getChallengeById(challengeId)
              const completed = isCompleted(challengeId)
              const hasPhoto = hasSubmission(challengeId)

              return (
                <div
                  key={`${rowIndex}-${colIndex}`}
                  className={`
                    flex flex-col items-center justify-between rounded-md p-2 h-32 md:h-40 transition-all
                    ${
                      completed
                        ? "bg-green-500 dark:bg-green-700 text-white font-medium scale-105"
                        : hasPhoto
                          ? "bg-yellow-100 dark:bg-yellow-900"
                          : "bg-card hover:bg-muted"
                    }
                    ${!challenge ? "bg-gray-100 dark:bg-gray-800" : ""}
                  `}
                >
                  {challenge ? (
                    <>
                      <div className="text-center text-xs md:text-sm flex-1 flex items-center">{challenge.title}</div>
                      <Link href={`/challenge/${challengeId}`} className="w-full mt-2">
                        <Button variant={completed ? "secondary" : "default"} size="sm" className="w-full">
                          {completed ? <Check className="h-4 w-4 mr-1" /> : <Camera className="h-4 w-4 mr-1" />}
                          {completed ? t("approved") : hasPhoto ? t("pending") : t("upload")}
                        </Button>
                      </Link>
                    </>
                  ) : (
                    <div className="text-muted-foreground">Loading...</div>
                  )}
                </div>
              )
            }),
          )}
        </div>
      </CardContent>
    </Card>
  )
}
