"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Upload, Loader2 } from "lucide-react"

interface PhotoUploadProps {
  onUpload: (file: File) => Promise<void>
  uploading: boolean
}

export default function PhotoUpload({ onUpload, uploading }: PhotoUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
      setSelectedFile(null)
      setPreview(null)
      return
    }

    const file = e.target.files[0]
    setSelectedFile(file)

    // Create a preview
    const reader = new FileReader()
    reader.onloadend = () => {
      setPreview(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleUpload = async () => {
    if (selectedFile) {
      await onUpload(selectedFile)
      setSelectedFile(null)
      setPreview(null)
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  return (
    <div className="w-full">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        capture="environment"
        className="hidden"
      />

      {preview && (
        <div className="mb-4">
          <div className="relative aspect-video w-full overflow-hidden rounded-md mb-2">
            <img src={preview || "/placeholder.svg"} alt="Preview" className="object-cover w-full h-full" />
          </div>
        </div>
      )}

      <div className="flex gap-2">
        <Button type="button" onClick={triggerFileInput} variant="outline" className="flex-1" disabled={uploading}>
          {selectedFile ? "Change Photo" : "Select Photo"}
        </Button>

        {selectedFile && (
          <Button type="button" onClick={handleUpload} className="flex items-center gap-2 flex-1" disabled={uploading}>
            {uploading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="h-4 w-4" />
                Upload
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  )
}
