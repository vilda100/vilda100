"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Volume2 } from "lucide-react"

interface NumberCallerProps {
  calledNumbers: number[]
  lastCalledNumber: number | null
  onCallNumber: () => void
  autoPlay: boolean
  setAutoPlay: (value: boolean) => void
}

export default function NumberCaller({
  calledNumbers,
  lastCalledNumber,
  onCallNumber,
  autoPlay,
  setAutoPlay,
}: NumberCallerProps) {
  const letters = ["B", "I", "N", "G", "O"]

  // Get the letter for a number
  const getLetterForNumber = (num: number) => {
    if (num <= 15) return "B"
    if (num <= 30) return "I"
    if (num <= 45) return "N"
    if (num <= 60) return "G"
    return "O"
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="p-6 flex flex-col items-center">
          {lastCalledNumber ? (
            <div className="flex flex-col items-center">
              <div className="text-6xl font-bold mb-2">
                {getLetterForNumber(lastCalledNumber)}-{lastCalledNumber}
              </div>
              <div className="text-sm text-muted-foreground">{calledNumbers.length} of 75 numbers called</div>
            </div>
          ) : (
            <div className="text-2xl text-center text-muted-foreground py-8">Press "Call Number" to start the game</div>
          )}

          <div className="flex items-center gap-4 mt-6">
            <Button
              onClick={onCallNumber}
              size="lg"
              disabled={calledNumbers.length >= 75}
              className="flex items-center gap-2"
            >
              <Volume2 className="h-4 w-4" />
              Call Number
            </Button>

            <div className="flex items-center space-x-2">
              <Switch id="auto-call" checked={autoPlay} onCheckedChange={setAutoPlay} />
              <Label htmlFor="auto-call">Auto-call</Label>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="w-full max-w-3xl mx-auto">
        <h3 className="text-xl font-bold mb-4">Called Numbers</h3>
        <div className="grid grid-cols-5 gap-4">
          {letters.map((letter) => (
            <div key={letter} className="space-y-2">
              <div className="text-center font-bold bg-primary text-primary-foreground py-2 rounded-md">{letter}</div>
              <div className="grid grid-cols-3 gap-2">
                {Array.from({ length: 15 }, (_, i) => {
                  const min = letter === "B" ? 1 : letter === "I" ? 16 : letter === "N" ? 31 : letter === "G" ? 46 : 61
                  const num = min + i
                  const isCalled = calledNumbers.includes(num)

                  return (
                    <div
                      key={num}
                      className={`
                        text-center py-1 rounded-md text-sm
                        ${isCalled ? "bg-green-500 dark:bg-green-700 text-white font-bold" : "bg-gray-100 dark:bg-gray-800"}
                      `}
                    >
                      {num}
                    </div>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
