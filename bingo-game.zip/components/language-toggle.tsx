"use client"

import { Button } from "@/components/ui/button"
import { useLanguage } from "@/lib/language-context"

export default function LanguageToggle() {
  const { language, toggleLanguage } = useLanguage()

  return (
    <Button
      variant="secondary"
      size="sm"
      onClick={toggleLanguage}
      className="flex items-center gap-2 bg-white text-black hover:bg-gray-100"
    >
      {language === "en" ? "🇨🇿 Česky" : "🇬🇧 English"}
    </Button>
  )
}
