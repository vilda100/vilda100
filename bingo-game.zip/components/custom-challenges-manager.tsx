"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useSupabase } from "./supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Plus, Trash2, Edit, Save, X, Share2 } from "lucide-react"
import LanguageToggle from "./language-toggle"
import type { CustomChallenge } from "@/lib/types"

interface CustomChallengesManagerProps {
  initialChallenges: CustomChallenge[]
  userId: string
}

export default function CustomChallengesManager({ initialChallenges, userId }: CustomChallengesManagerProps) {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { t, isCzechMode } = useLanguage()
  const [challenges, setChallenges] = useState<CustomChallenge[]>(initialChallenges)
  const [isAddingNew, setIsAddingNew] = useState(false)
  const [editingId, setEditingId] = useState<number | null>(null)

  // Form state
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [difficulty, setDifficulty] = useState("easy")
  const [category, setCategory] = useState("custom")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const resetForm = () => {
    setTitle("")
    setDescription("")
    setDifficulty("easy")
    setCategory("custom")
    setIsAddingNew(false)
    setEditingId(null)
  }

  const handleAddChallenge = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Validate form
      if (!title.trim()) {
        throw new Error(isCzechMode ? "Název výzvy je povinný" : "Challenge title is required")
      }

      // Create new challenge
      const { data, error } = await supabase
        .from("custom_challenges")
        .insert({
          user_id: userId,
          title,
          description,
          difficulty,
          category,
        })
        .select()

      if (error) throw error

      // Update local state
      if (data && data[0]) {
        setChallenges([data[0], ...challenges])
        toast({
          title: t("challengeAdded"),
          description: t("challengeAddedDesc"),
        })
        resetForm()
      }
    } catch (error: any) {
      toast({
        title: t("errorAddingChallenge"),
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleUpdateChallenge = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingId) return

    setIsSubmitting(true)

    try {
      // Validate form
      if (!title.trim()) {
        throw new Error(isCzechMode ? "Název výzvy je povinný" : "Challenge title is required")
      }

      // Update challenge
      const { error } = await supabase
        .from("custom_challenges")
        .update({
          title,
          description,
          difficulty,
          category,
        })
        .eq("id", editingId)
        .eq("user_id", userId)

      if (error) throw error

      // Update local state
      setChallenges(
        challenges.map((challenge) =>
          challenge.id === editingId ? { ...challenge, title, description, difficulty, category } : challenge,
        ),
      )

      toast({
        title: t("challengeUpdated"),
        description: t("challengeUpdatedDesc"),
      })

      resetForm()
    } catch (error: any) {
      toast({
        title: t("errorUpdatingChallenge"),
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteChallenge = async (id: number) => {
    if (!confirm(t("confirmDeleteChallenge"))) {
      return
    }

    try {
      const { error } = await supabase.from("custom_challenges").delete().eq("id", id).eq("user_id", userId)

      if (error) throw error

      // Update local state
      setChallenges(challenges.filter((challenge) => challenge.id !== id))

      toast({
        title: t("challengeDeleted"),
        description: t("challengeDeletedDesc"),
      })
    } catch (error: any) {
      toast({
        title: t("errorDeletingChallenge"),
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleEditChallenge = (challenge: CustomChallenge) => {
    setTitle(challenge.title)
    setDescription(challenge.description || "")
    setDifficulty(challenge.difficulty || "easy")
    setCategory(challenge.category || "custom")
    setEditingId(challenge.id)
    setIsAddingNew(false)

    // Scroll to form
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const difficultyOptions = [
    { value: "easy", label: t("easy") },
    { value: "medium", label: t("medium") },
    { value: "hard", label: t("hard") },
  ]

  const categoryOptions = [
    { value: "custom", label: t("custom") },
    { value: "food", label: t("food") },
    { value: "drinks", label: t("drinks") },
    { value: "landmarks", label: t("landmarks") },
    { value: "nature", label: t("nature") },
    { value: "people", label: t("people") },
    { value: "animals", label: t("animals") },
    { value: "architecture", label: t("architecture") },
    { value: "art", label: t("art") },
    { value: "transportation", label: t("transportation") },
    { value: "technology", label: t("technology") },
    { value: "sports", label: t("sports") },
    { value: "everyday", label: t("everyday") },
    { value: "funny", label: t("funny") },
  ]

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{t("customChallenges")}</h1>
        <div className="flex gap-2">
          <LanguageToggle />
          <Link href="/share">
            <Button variant="outline" className="flex items-center gap-2">
              <Share2 className="h-4 w-4" />
              {isCzechMode ? "Sdílet výzvy" : "Share Challenges"}
            </Button>
          </Link>
          <Button variant="outline" onClick={() => router.push("/game")} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            {t("backToGame")}
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>
                {editingId ? t("editChallenge") : isAddingNew ? t("addNewChallenge") : t("customChallenges")}
              </CardTitle>
              <CardDescription>
                {isCzechMode
                  ? "Vytvořte si vlastní výzvy pro vaši bingo hru"
                  : "Create your own challenges for your bingo game"}
              </CardDescription>
            </CardHeader>

            {isAddingNew || editingId !== null ? (
              <form onSubmit={editingId ? handleUpdateChallenge : handleAddChallenge}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="title" className="text-sm font-medium">
                      {t("challengeTitle")}*
                    </label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder={t("challengeTitlePlaceholder")}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="description" className="text-sm font-medium">
                      {t("challengeDescription")}
                    </label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder={t("challengeDescriptionPlaceholder")}
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="difficulty" className="text-sm font-medium">
                        {t("difficulty")}
                      </label>
                      <Select value={difficulty} onValueChange={setDifficulty}>
                        <SelectTrigger id="difficulty">
                          <SelectValue placeholder={t("selectDifficulty")} />
                        </SelectTrigger>
                        <SelectContent>
                          {difficultyOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="category" className="text-sm font-medium">
                        {t("category")}
                      </label>
                      <Select value={category} onValueChange={setCategory}>
                        <SelectTrigger id="category">
                          <SelectValue placeholder={t("selectCategory")} />
                        </SelectTrigger>
                        <SelectContent>
                          {categoryOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="flex justify-between">
                  <Button type="button" variant="outline" onClick={resetForm} disabled={isSubmitting}>
                    <X className="h-4 w-4 mr-2" />
                    {t("cancel")}
                  </Button>

                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? (
                      t("saving")
                    ) : editingId ? (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        {t("saveChanges")}
                      </>
                    ) : (
                      <>
                        <Plus className="h-4 w-4 mr-2" />
                        {t("addChallenge")}
                      </>
                    )}
                  </Button>
                </CardFooter>
              </form>
            ) : (
              <CardContent>
                <Button onClick={() => setIsAddingNew(true)} className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  {t("addNewChallenge")}
                </Button>
              </CardContent>
            )}
          </Card>

          <div className="space-y-4">
            {challenges.length > 0 ? (
              challenges.map((challenge) => (
                <Card key={challenge.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-xl">{challenge.title}</CardTitle>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon" onClick={() => handleEditChallenge(challenge)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteChallenge(challenge.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription className="flex flex-wrap gap-2 mt-1">
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                        {difficultyOptions.find((o) => o.value === challenge.difficulty)?.label || challenge.difficulty}
                      </span>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary/10 text-secondary">
                        {categoryOptions.find((o) => o.value === challenge.category)?.label || challenge.category}
                      </span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{challenge.description || t("noDescription")}</p>
                  </CardContent>
                  <CardFooter>
                    <Button
                      variant="outline"
                      size="sm"
                      className="ml-auto"
                      onClick={() => router.push(`/share?challenge=${challenge.id}`)}
                    >
                      <Share2 className="h-4 w-4 mr-2" />
                      {isCzechMode ? "Sdílet" : "Share"}
                    </Button>
                  </CardFooter>
                </Card>
              ))
            ) : (
              <div className="text-center py-12 bg-muted rounded-lg">
                <p className="text-muted-foreground">{t("noCustomChallengesYet")}</p>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t("aboutCustomChallenges")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>{t("customChallengesDescription")}</p>
              <p>{t("customChallengesWillAppear")}</p>
              <p>{t("tipsForGoodChallenges")}</p>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>{t("tipSpecific")}</li>
                <li>{t("tipDifficulty")}</li>
                <li>{t("tipCategories")}</li>
                <li>{t("tipCreative")}</li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => router.push("/game")}>
                {t("backToGame")}
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "Sdílení výzev" : "Challenge Sharing"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                {isCzechMode
                  ? "Sdílejte své vlastní výzvy s přáteli a dalšími hráči."
                  : "Share your custom challenges with friends and other players."}
              </p>
              <p>
                {isCzechMode
                  ? "Vytvořte unikátní odkaz, který můžete poslat komukoliv."
                  : "Create a unique link that you can send to anyone."}
              </p>
              <Link href="/share">
                <Button className="w-full">
                  <Share2 className="h-4 w-4 mr-2" />
                  {isCzechMode ? "Sdílet výzvy" : "Share Challenges"}
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
