"use client"

import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import Link from "next/link"
import { useLanguage } from "@/lib/language-context"

export default function GuestBanner() {
  const { t } = useLanguage()

  return (
    <Alert className="mb-6 bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800">
      <AlertCircle className="h-4 w-4 text-yellow-600 dark:text-yellow-500" />
      <AlertTitle>{t("guestModeTitle")}</AlertTitle>
      <AlertDescription className="flex flex-col sm:flex-row sm:items-center gap-2">
        <span>{t("guestModeDesc")}</span>
        <Link href="/auth/sign-up" className="text-primary hover:underline font-medium">
          {t("createAccountToSave")}
        </Link>
      </AlertDescription>
    </Alert>
  )
}
