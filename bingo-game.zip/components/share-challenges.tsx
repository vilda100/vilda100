"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "./supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Share2, Copy, Check, ExternalLink } from "lucide-react"
import LanguageToggle from "./language-toggle"
import { generateShareCode } from "@/lib/share-utils"
import type { CustomChallenge } from "@/lib/types"

interface ShareChallengesProps {
  customChallenges: CustomChallenge[]
  sharedChallenges: any[]
  userId: string
}

export default function ShareChallenges({ customChallenges, sharedChallenges, userId }: ShareChallengesProps) {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { t, isCzechMode } = useLanguage()
  const [selectedChallenges, setSelectedChallenges] = useState<number[]>([])
  const [isSharing, setIsSharing] = useState(false)
  const [shareUrl, setShareUrl] = useState<string>("")
  const [copied, setCopied] = useState(false)

  const handleSelectChallenge = (id: number) => {
    setSelectedChallenges((prev) => {
      if (prev.includes(id)) {
        return prev.filter((challengeId) => challengeId !== id)
      } else {
        return [...prev, id]
      }
    })
  }

  const handleShareChallenges = async () => {
    if (selectedChallenges.length === 0) {
      toast({
        title: isCzechMode ? "Žádné výzvy nevybrány" : "No challenges selected",
        description: isCzechMode
          ? "Vyberte alespoň jednu výzvu ke sdílení"
          : "Please select at least one challenge to share",
        variant: "destructive",
      })
      return
    }

    setIsSharing(true)

    try {
      // For simplicity, we'll just share the first selected challenge for now
      // In a full implementation, you might want to support sharing multiple challenges at once
      const challengeId = selectedChallenges[0]
      const challenge = customChallenges.find((c) => c.id === challengeId)

      if (!challenge) {
        throw new Error(isCzechMode ? "Výzva nenalezena" : "Challenge not found")
      }

      // Generate a unique share code
      const shareCode = generateShareCode()

      // Create a shared challenge record
      const { data, error } = await supabase
        .from("shared_challenges")
        .insert({
          challenge_id: challenge.id,
          creator_id: userId,
          share_code: shareCode,
          title: challenge.title,
          description: challenge.description,
          difficulty: challenge.difficulty,
          category: challenge.category,
        })
        .select()

      if (error) throw error

      // Generate the share URL
      const baseUrl = window.location.origin
      const newShareUrl = `${baseUrl}/import/${shareCode}`
      setShareUrl(newShareUrl)

      toast({
        title: isCzechMode ? "Výzva sdílena" : "Challenge shared",
        description: isCzechMode ? "Odkaz ke sdílení byl vygenerován" : "Share link has been generated",
      })
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba při sdílení" : "Error sharing challenge",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsSharing(false)
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)

    toast({
      title: isCzechMode ? "Zkopírováno" : "Copied",
      description: isCzechMode ? "Odkaz byl zkopírován do schránky" : "Link has been copied to clipboard",
    })
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{isCzechMode ? "Sdílet výzvy" : "Share Challenges"}</h1>
        <div className="flex gap-2">
          <LanguageToggle />
          <Button
            variant="outline"
            onClick={() => router.push("/custom-challenges")}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            {isCzechMode ? "Zpět na vlastní výzvy" : "Back to Custom Challenges"}
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {shareUrl ? (
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>{isCzechMode ? "Výzva sdílena" : "Challenge Shared"}</CardTitle>
                <CardDescription>
                  {isCzechMode
                    ? "Sdílejte tento odkaz s přáteli, aby mohli importovat vaši výzvu"
                    : "Share this link with friends so they can import your challenge"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Input value={shareUrl} readOnly className="flex-1" />
                  <Button variant="outline" size="icon" onClick={copyToClipboard}>
                    {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setShareUrl("")}>
                  {isCzechMode ? "Sdílet další výzvu" : "Share Another Challenge"}
                </Button>
                <Button onClick={() => window.open(shareUrl, "_blank")}>
                  <ExternalLink className="h-4 w-4 mr-2" />
                  {isCzechMode ? "Otevřít odkaz" : "Open Link"}
                </Button>
              </CardFooter>
            </Card>
          ) : (
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>{isCzechMode ? "Vyberte výzvy ke sdílení" : "Select Challenges to Share"}</CardTitle>
                <CardDescription>
                  {isCzechMode
                    ? "Vyberte výzvy, které chcete sdílet s ostatními hráči"
                    : "Select challenges you want to share with other players"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {customChallenges.length > 0 ? (
                  <div className="space-y-4">
                    {customChallenges.map((challenge) => (
                      <div key={challenge.id} className="flex items-start space-x-3 p-3 rounded-md border">
                        <Checkbox
                          id={`challenge-${challenge.id}`}
                          checked={selectedChallenges.includes(challenge.id)}
                          onCheckedChange={() => handleSelectChallenge(challenge.id)}
                        />
                        <div className="grid gap-1.5">
                          <label
                            htmlFor={`challenge-${challenge.id}`}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {challenge.title}
                          </label>
                          <p className="text-sm text-muted-foreground">
                            {challenge.description || (isCzechMode ? "Bez popisu" : "No description")}
                          </p>
                          <div className="flex flex-wrap gap-2 mt-1">
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                              {challenge.difficulty}
                            </span>
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary/10 text-secondary">
                              {challenge.category}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-muted rounded-lg">
                    <p className="text-muted-foreground">
                      {isCzechMode
                        ? "Zatím nemáte žádné vlastní výzvy. Vytvořte si výzvy, které můžete sdílet."
                        : "You don't have any custom challenges yet. Create challenges that you can share."}
                    </p>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button
                  onClick={handleShareChallenges}
                  disabled={selectedChallenges.length === 0 || isSharing}
                  className="w-full"
                >
                  <Share2 className="h-4 w-4 mr-2" />
                  {isSharing
                    ? isCzechMode
                      ? "Sdílení..."
                      : "Sharing..."
                    : isCzechMode
                      ? "Sdílet vybrané výzvy"
                      : "Share Selected Challenges"}
                </Button>
              </CardFooter>
            </Card>
          )}

          {sharedChallenges.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold">{isCzechMode ? "Vaše sdílené výzvy" : "Your Shared Challenges"}</h2>
              {sharedChallenges.map((challenge) => (
                <Card key={challenge.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-xl">{challenge.title}</CardTitle>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          {challenge.times_imported} {isCzechMode ? "importů" : "imports"}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            const baseUrl = window.location.origin
                            const url = `${baseUrl}/import/${challenge.share_code}`
                            navigator.clipboard.writeText(url)
                            toast({
                              title: isCzechMode ? "Zkopírováno" : "Copied",
                              description: isCzechMode
                                ? "Odkaz byl zkopírován do schránky"
                                : "Link has been copied to clipboard",
                            })
                          }}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription className="flex flex-wrap gap-2 mt-1">
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                        {challenge.difficulty}
                      </span>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary/10 text-secondary">
                        {challenge.category}
                      </span>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                        {isCzechMode ? "Sdíleno" : "Shared"}
                      </span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      {challenge.description || (isCzechMode ? "Bez popisu" : "No description")}
                    </p>
                    <div className="mt-2 text-xs text-muted-foreground">
                      <span className="font-medium">{isCzechMode ? "Kód pro sdílení:" : "Share code:"}</span>{" "}
                      {challenge.share_code}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "O sdílení výzev" : "About Sharing Challenges"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                {isCzechMode
                  ? "Sdílení výzev vám umožňuje sdílet vaše vlastní výzvy s přáteli a dalšími hráči."
                  : "Challenge sharing allows you to share your custom challenges with friends and other players."}
              </p>
              <p>
                {isCzechMode
                  ? "Když sdílíte výzvu, vytvoří se unikátní odkaz, který můžete poslat komukoliv."
                  : "When you share a challenge, a unique link is created that you can send to anyone."}
              </p>
              <p>
                {isCzechMode
                  ? "Ostatní hráči mohou importovat vaše výzvy do své hry a používat je ve svých bingo kartách."
                  : "Other players can import your challenges into their game and use them in their bingo cards."}
              </p>
              <p>{isCzechMode ? "Jak sdílet výzvy:" : "How to share challenges:"}</p>
              <ol className="list-decimal list-inside space-y-1 text-sm">
                <li>
                  {isCzechMode ? "Vyberte výzvy, které chcete sdílet" : "Select the challenges you want to share"}
                </li>
                <li>
                  {isCzechMode
                    ? "Klikněte na tlačítko 'Sdílet vybrané výzvy'"
                    : "Click the 'Share Selected Challenges' button"}
                </li>
                <li>
                  {isCzechMode
                    ? "Zkopírujte vygenerovaný odkaz a sdílejte ho s přáteli"
                    : "Copy the generated link and share it with friends"}
                </li>
              </ol>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => router.push("/custom-challenges")}>
                {isCzechMode ? "Zpět na vlastní výzvy" : "Back to Custom Challenges"}
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "Importovat výzvu" : "Import a Challenge"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                {isCzechMode
                  ? "Máte kód pro sdílení od přítele? Importujte jeho výzvu do své hry!"
                  : "Have a share code from a friend? Import their challenge into your game!"}
              </p>
              <div className="flex flex-col gap-4">
                <Input
                  placeholder={isCzechMode ? "Zadejte kód pro sdílení" : "Enter share code"}
                  id="share-code"
                  className="w-full"
                />
                <Button
                  onClick={() => {
                    const codeInput = document.getElementById("share-code") as HTMLInputElement
                    const code = codeInput?.value
                    if (code) {
                      router.push(`/import/${code}`)
                    } else {
                      toast({
                        title: isCzechMode ? "Chybí kód" : "Missing code",
                        description: isCzechMode ? "Zadejte kód pro sdílení" : "Please enter a share code",
                        variant: "destructive",
                      })
                    }
                  }}
                >
                  {isCzechMode ? "Importovat výzvu" : "Import Challenge"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
