"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Camera, Grid, Upload, UserPlus } from "lucide-react"
import { generateGuestId, saveGuestId } from "@/lib/guest-utils"
import { useLanguage } from "@/lib/language-context"
import LanguageToggle from "./language-toggle"

export default function LandingPage() {
  const router = useRouter()
  const { t } = useLanguage()

  const handleGuestPlay = () => {
    // Generate and save a guest ID
    const guestId = generateGuestId()
    saveGuestId(guestId)

    // Redirect to the game
    router.push("/game")
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-primary text-primary-foreground py-4">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">{t("photoChallengeBingo")}</h1>
            <div className="flex items-center gap-2">
              <LanguageToggle />
              <Link href="/auth/sign-in">
                <Button variant="secondary" size="sm">
                  {t("signIn")}
                </Button>
              </Link>
              <Link href="/auth/sign-up">
                <Button size="sm">{t("signUp")}</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-20 bg-gradient-to-b from-primary/10 to-background">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold mb-6">{t("tagline")}</h2>
            <p className="text-xl mb-10 max-w-2xl mx-auto">{t("description")}</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="animate-pulse" onClick={handleGuestPlay}>
                {t("playAsGuest")}
              </Button>
              <Link href="/auth/sign-up">
                <Button size="lg" variant="outline">
                  {t("createAccount")}
                </Button>
              </Link>
            </div>
            <p className="text-sm text-muted-foreground mt-4">{t("guestModeWarning")}</p>
          </div>
        </section>

        <section className="py-16 bg-background">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-10 text-center">{t("howItWorks")}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card">
                <div className="bg-primary/10 p-4 rounded-full mb-4">
                  <Grid className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">{t("getYourBingoCard")}</h3>
                <p>{t("getYourBingoCardDesc")}</p>
              </div>
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card">
                <div className="bg-primary/10 p-4 rounded-full mb-4">
                  <Camera className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">{t("completeChallenges")}</h3>
                <p>{t("completeChallengesDesc")}</p>
              </div>
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card">
                <div className="bg-primary/10 p-4 rounded-full mb-4">
                  <Upload className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">{t("uploadProof")}</h3>
                <p>{t("uploadProofDesc")}</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-muted">
          <div className="container mx-auto px-4 text-center">
            <div className="bg-primary/10 p-4 rounded-full mb-4 inline-block">
              <UserPlus className="h-10 w-10 text-primary" />
            </div>
            <h2 className="text-3xl font-bold mb-6">{t("whyCreateAccount")}</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">{t("whyCreateAccountDesc")}</p>
            <Link href="/auth/sign-up">
              <Button size="lg">{t("createAccount")}</Button>
            </Link>
          </div>
        </section>
      </main>

      <footer className="bg-muted py-6">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} {t("photoChallengeBingo")}
          </p>
        </div>
      </footer>
    </div>
  )
}
