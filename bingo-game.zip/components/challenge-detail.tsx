"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { useSupabase } from "./supabase-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Camera, CheckCircle, Clock } from "lucide-react"
import PhotoUpload from "./photo-upload"
import type { Challenge, Submission } from "@/lib/types"

interface ChallengeDetailProps {
  challenge: Challenge
  submission?: Submission
  userId: string
}

export default function ChallengeDetail({ challenge, submission, userId }: ChallengeDetailProps) {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const [uploading, setUploading] = useState(false)
  const [photoUrl, setPhotoUrl] = useState<string | null>(submission?.photo_url || null)

  const handlePhotoUpload = async (file: File) => {
    if (!file) return

    setUploading(true)

    try {
      // Upload the photo to Supabase Storage
      const fileExt = file.name.split(".").pop()
      const fileName = `${userId}/${challenge.id}/${Math.random()}.${fileExt}`
      const filePath = `photos/${fileName}`

      const { error: uploadError, data } = await supabase.storage.from("challenge-photos").upload(filePath, file)

      if (uploadError) throw uploadError

      // Get the public URL
      const {
        data: { publicUrl },
      } = supabase.storage.from("challenge-photos").getPublicUrl(filePath)

      // Create or update the submission record
      if (submission) {
        // Update existing submission
        const { error } = await supabase
          .from("submissions")
          .update({
            photo_url: publicUrl,
            status: "pending",
            updated_at: new Date().toISOString(),
          })
          .eq("id", submission.id)

        if (error) throw error
      } else {
        // Create new submission
        const { error } = await supabase.from("submissions").insert({
          user_id: userId,
          challenge_id: challenge.id,
          photo_url: publicUrl,
          status: "pending",
        })

        if (error) throw error

        // Update the bingo card to mark this challenge as completed
        const { data: bingoCard } = await supabase
          .from("bingo_cards")
          .select("completed_challenges")
          .eq("user_id", userId)
          .single()

        if (bingoCard) {
          const completedChallenges = bingoCard.completed_challenges || []
          if (!completedChallenges.includes(challenge.id)) {
            const { error: updateError } = await supabase
              .from("bingo_cards")
              .update({
                completed_challenges: [...completedChallenges, challenge.id],
                updated_at: new Date().toISOString(),
              })
              .eq("user_id", userId)

            if (updateError) throw updateError
          }
        }
      }

      setPhotoUrl(publicUrl)

      toast({
        title: "Photo uploaded successfully",
        description: "Your submission is pending approval.",
      })

      router.refresh()
    } catch (error: any) {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Button variant="ghost" onClick={() => router.push("/game")} className="mb-6 flex items-center gap-2">
        <ArrowLeft className="h-4 w-4" />
        Back to Bingo Card
      </Button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>{challenge.title}</CardTitle>
            <CardDescription>
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary mr-2">
                {challenge.difficulty}
              </span>
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary/10 text-secondary">
                {challenge.category}
              </span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p>{challenge.description}</p>
          </CardContent>
          <CardFooter>
            <div className="text-sm text-muted-foreground">
              Complete this challenge by taking a photo that matches the description.
            </div>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Your Submission</CardTitle>
            <CardDescription>
              {submission ? (
                <div className="flex items-center gap-2">
                  {submission.status === "approved" ? (
                    <>
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Approved</span>
                    </>
                  ) : submission.status === "rejected" ? (
                    <>
                      <span className="text-red-500">Rejected</span>
                    </>
                  ) : (
                    <>
                      <Clock className="h-4 w-4 text-yellow-500" />
                      <span>Pending approval</span>
                    </>
                  )}
                </div>
              ) : (
                <span>Upload a photo to complete this challenge</span>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {photoUrl ? (
              <div className="relative aspect-video w-full overflow-hidden rounded-md">
                <Image src={photoUrl || "/placeholder.svg"} alt="Challenge submission" fill className="object-cover" />
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 bg-muted rounded-md">
                <Camera className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No photo uploaded yet</p>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <PhotoUpload onUpload={handlePhotoUpload} uploading={uploading} />
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
