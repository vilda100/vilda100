"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "../supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Users, Clock, LogIn } from "lucide-react"
import LanguageToggle from "../language-toggle"

interface JoinGameSessionProps {
  gameSession: any
  userId: string
  username: string
  isParticipant: boolean
}

export default function JoinGameSession({ gameSession, userId, username, isParticipant }: JoinGameSessionProps) {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { t, isCzechMode } = useLanguage()
  const [isJoining, setIsJoining] = useState(false)

  const handleJoinSession = async () => {
    if (isParticipant) {
      router.push(`/multiplayer/session/${gameSession.id}`)
      return
    }

    setIsJoining(true)

    try {
      // Check if the game is full
      if (gameSession.players.length >= gameSession.max_players) {
        throw new Error(isCzechMode ? "Hra je plná" : "Game is full")
      }

      // Add user as a player
      const { error: playerError } = await supabase.from("session_players").insert({
        session_id: gameSession.id,
        user_id: userId,
        display_name: username,
      })

      if (playerError) throw playerError

      // Create a session event for player joining
      await supabase.from("session_events").insert({
        session_id: gameSession.id,
        user_id: userId,
        event_type: "player_joined",
        event_data: { player_name: username },
      })

      toast({
        title: isCzechMode ? "Připojeno ke hře" : "Joined Game",
        description: isCzechMode
          ? `Úspěšně jste se připojili ke hře "${gameSession.name}"`
          : `Successfully joined "${gameSession.name}"`,
      })

      router.push(`/multiplayer/session/${gameSession.id}`)
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba při připojování" : "Error joining game",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsJoining(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat(isCzechMode ? "cs-CZ" : "en-US", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{isCzechMode ? "Připojit se ke hře" : "Join Game"}</h1>
        <div className="flex gap-2">
          <LanguageToggle />
          <Button variant="outline" onClick={() => router.push("/multiplayer")} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            {isCzechMode ? "Zpět do lobby" : "Back to Lobby"}
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>{gameSession.name}</CardTitle>
              <CardDescription>
                {isCzechMode ? "Vytvořil(a)" : "Created by"}{" "}
                <span className="font-medium">{gameSession.creator?.username || "Unknown"}</span> •{" "}
                {formatDate(gameSession.created_at)}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>{gameSession.description || (isCzechMode ? "Bez popisu" : "No description")}</p>

              <div className="flex flex-wrap gap-4 mt-4">
                <div className="flex items-center gap-2 bg-primary/10 text-primary px-3 py-1.5 rounded-full text-sm">
                  <Users className="h-4 w-4" />
                  <span>
                    {gameSession.players.length} / {gameSession.max_players} {isCzechMode ? "hráčů" : "players"}
                  </span>
                </div>
                <div className="flex items-center gap-2 bg-secondary/10 text-secondary px-3 py-1.5 rounded-full text-sm">
                  <Clock className="h-4 w-4" />
                  <span>
                    {isCzechMode ? "Vytvořeno" : "Created"} {formatDate(gameSession.created_at)}
                  </span>
                </div>
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-medium mb-2">{isCzechMode ? "Kód pro připojení" : "Invite Code"}</h3>
                <div className="bg-muted p-3 rounded-md text-center font-mono text-lg">{gameSession.invite_code}</div>
                <p className="text-sm text-muted-foreground mt-2">
                  {isCzechMode
                    ? "Sdílejte tento kód s přáteli, aby se mohli připojit ke hře"
                    : "Share this code with friends so they can join the game"}
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleJoinSession} disabled={isJoining} className="w-full">
                <LogIn className="h-4 w-4 mr-2" />
                {isParticipant
                  ? isCzechMode
                    ? "Pokračovat ve hře"
                    : "Continue Game"
                  : isJoining
                    ? isCzechMode
                      ? "Připojování..."
                      : "Joining..."
                    : isCzechMode
                      ? "Připojit se ke hře"
                      : "Join Game"}
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "O této hře" : "About This Game"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                {isCzechMode
                  ? "Připojením se k této hře budete soutěžit s ostatními hráči o to, kdo první získá BINGO!"
                  : "By joining this game, you'll compete with other players to see who gets BINGO first!"}
              </p>
              <p>
                {isCzechMode
                  ? "Obdržíte vlastní bingo kartu s náhodnými výzvami. Plňte výzvy, nahrajte fotky a získejte BINGO!"
                  : "You'll receive your own bingo card with random challenges. Complete challenges, upload photos, and get BINGO!"}
              </p>
              <div className="mt-4">
                <h3 className="font-medium mb-2">
                  {isCzechMode ? "Co se stane po připojení:" : "What happens after joining:"}
                </h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>{isCzechMode ? "Obdržíte vlastní bingo kartu" : "You'll receive your own bingo card"}</li>
                  <li>
                    {isCzechMode
                      ? "Budete moci vidět ostatní hráče a jejich postup"
                      : "You'll be able to see other players and their progress"}
                  </li>
                  <li>
                    {isCzechMode
                      ? "Plňte výzvy a nahrajte fotky jako důkaz"
                      : "Complete challenges and upload photos as proof"}
                  </li>
                  <li>{isCzechMode ? "Získejte BINGO dříve než ostatní hráči!" : "Get BINGO before other players!"}</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
