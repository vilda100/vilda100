"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "../supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Users, Trophy, RefreshCw, MessageSquare, Share2 } from "lucide-react"
import LanguageToggle from "../language-toggle"
import BingoCard from "../bingo-card"
import PlayerList from "./player-list"
import SessionChat from "./session-chat"
import SessionEvents from "./session-events"

interface GameSessionProps {
  gameSession: any
  player: any
  players: any[]
  challenges: any[]
  bingoCard: any
  submissions: any[]
  userId: string
}

export default function GameSession({
  gameSession,
  player,
  players,
  challenges,
  bingoCard,
  submissions,
  userId,
}: GameSessionProps) {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { t, isCzechMode } = useLanguage()
  const [cardData, setCardData] = useState<number[][]>([])
  const [completedChallenges, setCompletedChallenges] = useState<number[]>([])
  const [loading, setLoading] = useState(false)
  const [hasWon, setHasWon] = useState(false)
  const [sessionPlayers, setSessionPlayers] = useState(players)
  const [events, setEvents] = useState<any[]>([])
  const [messages, setMessages] = useState<any[]>([])

  // Initialize the game
  useEffect(() => {
    if (bingoCard) {
      setCardData(bingoCard.card_data as number[][])
      setCompletedChallenges(bingoCard.completed_challenges || [])
      setHasWon(player.has_bingo)
    } else {
      generateNewCard()
    }

    // Fetch initial events
    fetchEvents()

    // Fetch initial messages
    fetchMessages()

    // Set up real-time subscriptions
    const playersSubscription = supabase
      .channel("session_players_changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "session_players",
          filter: `session_id=eq.${gameSession.id}`,
        },
        () => {
          fetchPlayers()
        },
      )
      .subscribe()

    const eventsSubscription = supabase
      .channel("session_events_changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "session_events",
          filter: `session_id=eq.${gameSession.id}`,
        },
        (payload) => {
          setEvents((prev) => [payload.new, ...prev])
        },
      )
      .subscribe()

    const messagesSubscription = supabase
      .channel("session_messages_changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "session_messages",
          filter: `session_id=eq.${gameSession.id}`,
        },
        (payload) => {
          setMessages((prev) => [...prev, payload.new])
        },
      )
      .subscribe()

    return () => {
      playersSubscription.unsubscribe()
      eventsSubscription.unsubscribe()
      messagesSubscription.unsubscribe()
    }
  }, [bingoCard, player, gameSession.id, supabase])

  // Check for win conditions whenever completed challenges change
  useEffect(() => {
    if (cardData.length > 0 && completedChallenges.length >= 5 && !hasWon) {
      checkForWin()
    }
  }, [completedChallenges, cardData, hasWon])

  const fetchPlayers = async () => {
    const { data } = await supabase
      .from("session_players")
      .select("*, user:user_id(username)")
      .eq("session_id", gameSession.id)
      .order("score", { ascending: false })

    if (data) {
      setSessionPlayers(data)
    }
  }

  const fetchEvents = async () => {
    const { data } = await supabase
      .from("session_events")
      .select("*, user:user_id(username)")
      .eq("session_id", gameSession.id)
      .order("created_at", { ascending: false })
      .limit(20)

    if (data) {
      setEvents(data)
    }
  }

  const fetchMessages = async () => {
    const { data } = await supabase
      .from("session_messages")
      .select("*, user:user_id(username)")
      .eq("session_id", gameSession.id)
      .order("created_at", { ascending: true })

    if (data) {
      setMessages(data)
    }
  }

  // Generate a new 5x5 bingo card with random challenges
  const generateNewCard = async () => {
    if (challenges.length < 25) {
      toast({
        title: "Not enough challenges",
        description: "There must be at least 25 challenges in the database to generate a card.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      // Shuffle challenges and pick 25
      const shuffled = [...challenges].sort(() => 0.5 - Math.random())
      const selected = shuffled.slice(0, 25)

      // Create a 5x5 grid
      const newCardData: number[][] = Array(5)
        .fill(0)
        .map(() => Array(5).fill(0))

      // Fill the grid with challenge IDs
      selected.forEach((challenge, index) => {
        const row = Math.floor(index / 5)
        const col = index % 5
        newCardData[row][col] = challenge.id
      })

      // Save the card to the database
      const { data: cardData, error: cardError } = await supabase
        .from("bingo_cards")
        .upsert({
          user_id: userId,
          card_data: newCardData,
          completed_challenges: [], // Start with no completed spaces
          updated_at: new Date().toISOString(),
        })
        .select()

      if (cardError) throw cardError

      // Update the player record with the card ID
      if (cardData && cardData.length > 0) {
        const { error: playerError } = await supabase
          .from("session_players")
          .update({
            card_id: cardData[0].id,
            last_active: new Date().toISOString(),
          })
          .eq("session_id", gameSession.id)
          .eq("user_id", userId)

        if (playerError) throw playerError
      }

      setCardData(newCardData)
      setCompletedChallenges([])

      // Create a session event for new card
      await supabase.from("session_events").insert({
        session_id: gameSession.id,
        user_id: userId,
        event_type: "new_card",
        event_data: {},
      })

      toast({
        title: "New card generated",
        description: "Your bingo card has been created with new challenges!",
      })

      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error generating card",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Check for winning patterns
  const checkForWin = async () => {
    if (!cardData.length || hasWon) return

    let hasWinningPattern = false

    // Check rows
    for (let row = 0; row < 5; row++) {
      if (cardData[row].every((challengeId) => completedChallenges.includes(challengeId))) {
        hasWinningPattern = true
        break
      }
    }

    // Check columns
    if (!hasWinningPattern) {
      for (let col = 0; col < 5; col++) {
        const column = cardData.map((row) => row[col])
        if (column.every((challengeId) => completedChallenges.includes(challengeId))) {
          hasWinningPattern = true
          break
        }
      }
    }

    // Check diagonals
    if (!hasWinningPattern) {
      const diagonal1 = [cardData[0][0], cardData[1][1], cardData[2][2], cardData[3][3], cardData[4][4]]
      const diagonal2 = [cardData[0][4], cardData[1][3], cardData[2][2], cardData[3][1], cardData[4][0]]

      if (
        diagonal1.every((challengeId) => completedChallenges.includes(challengeId)) ||
        diagonal2.every((challengeId) => completedChallenges.includes(challengeId))
      ) {
        hasWinningPattern = true
      }
    }

    if (hasWinningPattern) {
      setHasWon(true)

      // Update player record
      const { error: playerError } = await supabase
        .from("session_players")
        .update({
          has_bingo: true,
          score: completedChallenges.length,
          last_active: new Date().toISOString(),
        })
        .eq("session_id", gameSession.id)
        .eq("user_id", userId)

      if (playerError) {
        console.error("Error updating player:", playerError)
      }

      // Create a session event for bingo
      await supabase.from("session_events").insert({
        session_id: gameSession.id,
        user_id: userId,
        event_type: "bingo",
        event_data: { completed_challenges: completedChallenges.length },
      })

      celebrateWin()
    }
  }

  const celebrateWin = () => {
    toast({
      title: "BINGO!",
      description: t("youWon"),
      variant: "default",
    })
  }

  // Check if a challenge has a submission
  const hasSubmission = (challengeId: number) => {
    return submissions.some(
      (sub) => sub.challenge_id === challengeId && (sub.status === "approved" || sub.status === "pending"),
    )
  }

  const copyInviteLink = () => {
    const inviteUrl = `${window.location.origin}/multiplayer/join/${gameSession.invite_code}`
    navigator.clipboard.writeText(inviteUrl)
    toast({
      title: isCzechMode ? "Zkopírováno" : "Copied",
      description: isCzechMode ? "Odkaz pro pozvání byl zkopírován" : "Invite link has been copied",
    })
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">{gameSession.name}</h1>
          <p className="text-muted-foreground">
            {isCzechMode ? "Vytvořil(a)" : "Created by"}{" "}
            <span className="font-medium">{gameSession.creator?.username || "Unknown"}</span>
          </p>
        </div>
        <div className="flex gap-2">
          <LanguageToggle />
          <Button variant="outline" onClick={copyInviteLink} className="flex items-center gap-2">
            <Share2 className="h-4 w-4" />
            {isCzechMode ? "Pozvat" : "Invite"}
          </Button>
          <Button variant="outline" onClick={() => router.push("/multiplayer")} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            {isCzechMode ? "Zpět do lobby" : "Back to Lobby"}
          </Button>
        </div>
      </header>

      {hasWon && (
        <div className="flex items-center justify-center p-4 mb-8 bg-green-100 dark:bg-green-900 rounded-lg animate-pulse">
          <Trophy className="h-8 w-8 text-yellow-500 mr-2" />
          <span className="text-2xl font-bold">{t("youWon")}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Tabs defaultValue="card">
            <TabsList className="mb-4">
              <TabsTrigger value="card">{isCzechMode ? "Moje karta" : "My Card"}</TabsTrigger>
              <TabsTrigger value="players">
                <Users className="h-4 w-4 mr-2" />
                {isCzechMode ? "Hráči" : "Players"} ({sessionPlayers.length})
              </TabsTrigger>
              <TabsTrigger value="chat">
                <MessageSquare className="h-4 w-4 mr-2" />
                {isCzechMode ? "Chat" : "Chat"}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="card">
              <Card className="mb-4">
                <CardContent className="p-4">
                  <Button
                    variant="outline"
                    onClick={generateNewCard}
                    disabled={loading}
                    className="flex items-center gap-2 mb-4"
                  >
                    <RefreshCw className="h-4 w-4" />
                    {t("newCard")}
                  </Button>

                  <BingoCard
                    cardData={cardData}
                    challenges={challenges}
                    completedChallenges={completedChallenges}
                    hasSubmission={hasSubmission}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="players">
              <PlayerList players={sessionPlayers} currentUserId={userId} />
            </TabsContent>

            <TabsContent value="chat">
              <SessionChat sessionId={gameSession.id} userId={userId} messages={messages} setMessages={setMessages} />
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "Stav hry" : "Game Status"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">{isCzechMode ? "Hráči" : "Players"}</p>
                <p className="text-2xl font-bold">{sessionPlayers.length}</p>
              </div>

              <div>
                <p className="text-sm text-muted-foreground">{isCzechMode ? "Vaše skóre" : "Your Score"}</p>
                <p className="text-2xl font-bold">{completedChallenges.length} / 25</p>
              </div>

              <div>
                <p className="text-sm text-muted-foreground">{isCzechMode ? "Kód pro pozvání" : "Invite Code"}</p>
                <div className="flex items-center gap-2">
                  <p className="text-xl font-mono">{gameSession.invite_code}</p>
                  <Button variant="ghost" size="sm" onClick={copyInviteLink}>
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "Aktivita" : "Activity"}</CardTitle>
            </CardHeader>
            <CardContent>
              <SessionEvents events={events} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
