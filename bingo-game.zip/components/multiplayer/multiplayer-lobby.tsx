"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useSupabase } from "../supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Plus, Users, Trophy, LogIn, Medal } from "lucide-react"
import LanguageToggle from "../language-toggle"

interface MultiplayerLobbyProps {
  activeSessions: any[]
  userSessions: any[]
  userId: string
  username: string
}

export default function MultiplayerLobby({ activeSessions, userSessions, userId, username }: MultiplayerLobbyProps) {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { t, isCzechMode } = useLanguage()
  const [inviteCode, setInviteCode] = useState("")

  const handleJoinWithCode = () => {
    if (!inviteCode.trim()) {
      toast({
        title: isCzechMode ? "Chybí kód" : "Missing code",
        description: isCzechMode ? "Zadejte kód pro připojení" : "Please enter an invite code",
        variant: "destructive",
      })
      return
    }

    router.push(`/multiplayer/join/${inviteCode.trim()}`)
  }

  const formatPlayerCount = (players: any[]) => {
    return `${players.length} ${isCzechMode ? "hráčů" : "players"}`
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat(isCzechMode ? "cs-CZ" : "en-US", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{isCzechMode ? "Multiplayer" : "Multiplayer"}</h1>
        <div className="flex gap-2">
          <LanguageToggle />
          <Link href="/multiplayer/leaderboard">
            <Button variant="outline" className="flex items-center gap-2">
              <Medal className="h-4 w-4" />
              {isCzechMode ? "Žebříček" : "Leaderboard"}
            </Button>
          </Link>
          <Button variant="outline" onClick={() => router.push("/game")} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            {isCzechMode ? "Zpět na hru" : "Back to Game"}
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>{isCzechMode ? "Připojit se ke hře" : "Join a Game"}</CardTitle>
              <CardDescription>
                {isCzechMode
                  ? "Připojte se k existující hře pomocí kódu pro připojení"
                  : "Join an existing game using an invite code"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Input
                  placeholder={isCzechMode ? "Zadejte kód pro připojení" : "Enter invite code"}
                  value={inviteCode}
                  onChange={(e) => setInviteCode(e.target.value)}
                />
                <Button onClick={handleJoinWithCode}>{isCzechMode ? "Připojit se" : "Join"}</Button>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/multiplayer/create" className="w-full">
                <Button variant="outline" className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  {isCzechMode ? "Vytvořit novou hru" : "Create New Game"}
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Tabs defaultValue="active">
            <TabsList className="mb-4">
              <TabsTrigger value="active">{isCzechMode ? "Aktivní hry" : "Active Games"}</TabsTrigger>
              <TabsTrigger value="my">{isCzechMode ? "Moje hry" : "My Games"}</TabsTrigger>
            </TabsList>

            <TabsContent value="active">
              {activeSessions.length > 0 ? (
                <div className="space-y-4">
                  {activeSessions.map((session) => (
                    <Card key={session.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-xl">{session.name}</CardTitle>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Users className="h-4 w-4" />
                            <span>{formatPlayerCount(session.players)}</span>
                          </div>
                        </div>
                        <CardDescription>
                          {isCzechMode ? "Vytvořil(a)" : "Created by"}{" "}
                          <span className="font-medium">{session.creator?.username || "Unknown"}</span> •{" "}
                          {formatDate(session.created_at)}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm">
                          {session.description || (isCzechMode ? "Bez popisu" : "No description")}
                        </p>
                      </CardContent>
                      <CardFooter>
                        <Button
                          className="w-full"
                          onClick={() => router.push(`/multiplayer/join/${session.invite_code}`)}
                        >
                          <LogIn className="h-4 w-4 mr-2" />
                          {isCzechMode ? "Připojit se ke hře" : "Join Game"}
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-muted rounded-lg">
                  <p className="text-muted-foreground">
                    {isCzechMode
                      ? "Momentálně nejsou k dispozici žádné aktivní hry. Vytvořte novou hru!"
                      : "There are no active games available right now. Create a new game!"}
                  </p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="my">
              {userSessions.length > 0 ? (
                <div className="space-y-4">
                  {userSessions.map((session) => (
                    <Card key={session.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-xl">{session.name}</CardTitle>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Users className="h-4 w-4" />
                            <span>{formatPlayerCount(session.players)}</span>
                          </div>
                        </div>
                        <CardDescription>
                          {isCzechMode ? "Vytvořil(a)" : "Created by"}{" "}
                          <span className="font-medium">{session.creator?.username || "Unknown"}</span> •{" "}
                          {formatDate(session.created_at)}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm">
                          {session.description || (isCzechMode ? "Bez popisu" : "No description")}
                        </p>
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full" onClick={() => router.push(`/multiplayer/session/${session.id}`)}>
                          <Trophy className="h-4 w-4 mr-2" />
                          {isCzechMode ? "Pokračovat ve hře" : "Continue Game"}
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-muted rounded-lg">
                  <p className="text-muted-foreground">
                    {isCzechMode
                      ? "Nejste připojeni k žádným hrám. Připojte se k existující hře nebo vytvořte novou!"
                      : "You're not part of any games. Join an existing game or create a new one!"}
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "O multiplayeru" : "About Multiplayer"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                {isCzechMode
                  ? "Multiplayer mód vám umožňuje hrát bingo s přáteli a soutěžit o to, kdo první získá BINGO!"
                  : "Multiplayer mode allows you to play bingo with friends and compete to see who gets BINGO first!"}
              </p>
              <p>
                {isCzechMode
                  ? "Vytvořte novou hru a pozvěte přátele pomocí kódu pro připojení, nebo se připojte k existující hře."
                  : "Create a new game and invite friends using the invite code, or join an existing game."}
              </p>
              <p>{isCzechMode ? "Jak hrát multiplayer:" : "How to play multiplayer:"}</p>
              <ol className="list-decimal list-inside space-y-1 text-sm">
                <li>
                  {isCzechMode
                    ? "Vytvořte novou hru nebo se připojte k existující"
                    : "Create a new game or join an existing one"}
                </li>
                <li>
                  {isCzechMode ? "Každý hráč obdrží vlastní bingo kartu" : "Each player receives their own bingo card"}
                </li>
                <li>
                  {isCzechMode
                    ? "Plňte výzvy a nahrajte fotky jako důkaz"
                    : "Complete challenges and upload photos as proof"}
                </li>
                <li>
                  {isCzechMode
                    ? "Sledujte postup ostatních hráčů v reálném čase"
                    : "Track other players' progress in real-time"}
                </li>
                <li>
                  {isCzechMode ? "První hráč, který získá BINGO, vyhrává!" : "The first player to get BINGO wins!"}
                </li>
              </ol>
            </CardContent>
            <CardFooter>
              <Link href="/multiplayer/create" className="w-full">
                <Button className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  {isCzechMode ? "Vytvořit novou hru" : "Create New Game"}
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "Žebříček" : "Leaderboard"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                {isCzechMode
                  ? "Podívejte se na žebříček nejlepších hráčů a zjistěte, jak si vedete v porovnání s ostatními."
                  : "Check out the leaderboard to see the top players and find out how you rank compared to others."}
              </p>
              <Link href="/multiplayer/leaderboard">
                <Button variant="outline" className="w-full">
                  <Medal className="h-4 w-4 mr-2" />
                  {isCzechMode ? "Zobrazit žebříček" : "View Leaderboard"}
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
