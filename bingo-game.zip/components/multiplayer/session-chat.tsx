"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useSupabase } from "../supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { Send } from "lucide-react"

interface SessionChatProps {
  sessionId: number
  userId: string
  messages: any[]
  setMessages: React.Dispatch<React.SetStateAction<any[]>>
}

export default function SessionChat({ sessionId, userId, messages, setMessages }: SessionChatProps) {
  const { supabase } = useSupabase()
  const { isCzechMode } = useLanguage()
  const { toast } = useToast()
  const [message, setMessage] = useState("")
  const [isSending, setIsSending] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!message.trim()) return

    setIsSending(true)

    try {
      const { error } = await supabase.from("session_messages").insert({
        session_id: sessionId,
        user_id: userId,
        message: message.trim(),
      })

      if (error) throw error

      setMessage("")
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba při odesílání zprávy" : "Error sending message",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsSending(false)
    }
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString(isCzechMode ? "cs-CZ" : "en-US", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <Card className="flex flex-col h-[600px]">
      <CardContent className="flex-1 overflow-y-auto p-4">
        {messages.length > 0 ? (
          <div className="space-y-4">
            {messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.user_id === userId ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[80%] rounded-lg px-4 py-2 ${
                    msg.user_id === userId ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  <div className="flex justify-between items-center gap-4 mb-1">
                    <span className="font-medium text-xs">{msg.user?.username || "Player"}</span>
                    <span className="text-xs opacity-70">{formatTime(msg.created_at)}</span>
                  </div>
                  <p>{msg.message}</p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        ) : (
          <div className="h-full flex items-center justify-center">
            <p className="text-muted-foreground">
              {isCzechMode ? "Zatím žádné zprávy. Buďte první!" : "No messages yet. Be the first!"}
            </p>
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t p-4">
        <form onSubmit={handleSendMessage} className="flex w-full gap-2">
          <Input
            placeholder={isCzechMode ? "Napište zprávu..." : "Type a message..."}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            disabled={isSending}
          />
          <Button type="submit" size="icon" disabled={isSending || !message.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </CardFooter>
    </Card>
  )
}
