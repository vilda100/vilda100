"use client"

import { useLanguage } from "@/lib/language-context"
import { Trophy, User, RefreshCw, MessageSquare } from "lucide-react"

interface SessionEventsProps {
  events: any[]
}

export default function SessionEvents({ events }: SessionEventsProps) {
  const { isCzechMode } = useLanguage()

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString(isCzechMode ? "cs-CZ" : "en-US", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case "game_created":
        return <User className="h-4 w-4 text-primary" />
      case "player_joined":
        return <User className="h-4 w-4 text-green-500" />
      case "bingo":
        return <Trophy className="h-4 w-4 text-yellow-500" />
      case "new_card":
        return <RefreshCw className="h-4 w-4 text-blue-500" />
      default:
        return <MessageSquare className="h-4 w-4 text-gray-500" />
    }
  }

  const getEventText = (event: any) => {
    const username = event.user?.username || "Player"

    switch (event.event_type) {
      case "game_created":
        return isCzechMode ? `${username} vytvořil(a) hru` : `${username} created the game`
      case "player_joined":
        return isCzechMode ? `${username} se připojil(a) ke hře` : `${username} joined the game`
      case "bingo":
        return isCzechMode ? `${username} získal(a) BINGO!` : `${username} got BINGO!`
      case "new_card":
        return isCzechMode ? `${username} vygeneroval(a) novou kartu` : `${username} generated a new card`
      default:
        return isCzechMode ? `${username} provedl(a) akci` : `${username} performed an action`
    }
  }

  return (
    <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
      {events.length > 0 ? (
        events.map((event) => (
          <div key={event.id} className="flex items-start gap-3">
            <div className="mt-0.5">{getEventIcon(event.event_type)}</div>
            <div className="flex-1 text-sm">
              <p>{getEventText(event)}</p>
              <p className="text-xs text-muted-foreground">{formatTime(event.created_at)}</p>
            </div>
          </div>
        ))
      ) : (
        <p className="text-center text-muted-foreground text-sm py-4">
          {isCzechMode ? "Zatím žádná aktivita" : "No activity yet"}
        </p>
      )}
    </div>
  )
}
