"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "../supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Users, Clock } from "lucide-react"
import LanguageToggle from "../language-toggle"
import { generateInviteCode } from "@/lib/multiplayer-utils"

interface CreateGameSessionProps {
  userId: string
  username: string
}

export default function CreateGameSession({ userId, username }: CreateGameSessionProps) {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { t, isCzechMode } = useLanguage()
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [maxPlayers, setMaxPlayers] = useState(10)
  const [isCreating, setIsCreating] = useState(false)

  const handleCreateSession = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsCreating(true)

    try {
      // Validate form
      if (!name.trim()) {
        throw new Error(isCzechMode ? "Název hry je povinný" : "Game name is required")
      }

      // Generate a unique invite code
      const inviteCode = generateInviteCode()

      // Create new game session
      const { data: sessionData, error: sessionError } = await supabase
        .from("game_sessions")
        .insert({
          creator_id: userId,
          name,
          description,
          invite_code: inviteCode,
          max_players: maxPlayers,
        })
        .select()

      if (sessionError) throw sessionError

      if (!sessionData || sessionData.length === 0) {
        throw new Error(isCzechMode ? "Nepodařilo se vytvořit hru" : "Failed to create game session")
      }

      const sessionId = sessionData[0].id

      // Add creator as a player
      const { error: playerError } = await supabase.from("session_players").insert({
        session_id: sessionId,
        user_id: userId,
        display_name: username,
      })

      if (playerError) throw playerError

      // Create a session event for game creation
      await supabase.from("session_events").insert({
        session_id: sessionId,
        user_id: userId,
        event_type: "game_created",
        event_data: { creator_name: username },
      })

      toast({
        title: isCzechMode ? "Hra vytvořena" : "Game Created",
        description: isCzechMode ? `Kód pro pozvání: ${inviteCode}` : `Invite code: ${inviteCode}`,
      })

      router.push(`/multiplayer/session/${sessionId}`)
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba při vytváření hry" : "Error creating game",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsCreating(false)
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{isCzechMode ? "Vytvořit novou hru" : "Create New Game"}</h1>
        <div className="flex gap-2">
          <LanguageToggle />
          <Button variant="outline" onClick={() => router.push("/multiplayer")} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            {isCzechMode ? "Zpět do lobby" : "Back to Lobby"}
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card>
            <form onSubmit={handleCreateSession}>
              <CardHeader>
                <CardTitle>{isCzechMode ? "Nastavení hry" : "Game Settings"}</CardTitle>
                <CardDescription>
                  {isCzechMode
                    ? "Vytvořte novou multiplayer hru a pozvěte přátele"
                    : "Create a new multiplayer game and invite friends"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-medium">
                    {isCzechMode ? "Název hry" : "Game Name"}*
                  </label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={isCzechMode ? "Např. Víkendové bingo" : "E.g., Weekend Bingo Challenge"}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="description" className="text-sm font-medium">
                    {isCzechMode ? "Popis hry" : "Game Description"}
                  </label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder={isCzechMode ? "Nepovinný popis vaší hry" : "Optional description of your game"}
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="maxPlayers" className="text-sm font-medium">
                    {isCzechMode ? "Maximální počet hráčů" : "Maximum Players"}
                  </label>
                  <Input
                    id="maxPlayers"
                    type="number"
                    min={2}
                    max={20}
                    value={maxPlayers}
                    onChange={(e) => setMaxPlayers(Number.parseInt(e.target.value))}
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit" className="w-full" disabled={isCreating}>
                  {isCreating
                    ? isCzechMode
                      ? "Vytváření..."
                      : "Creating..."
                    : isCzechMode
                      ? "Vytvořit hru"
                      : "Create Game"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "O multiplayeru" : "About Multiplayer"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                {isCzechMode
                  ? "Vytvořením nové hry se stanete jejím hostitelem. Budete moci pozvat přátele pomocí vygenerovaného kódu pro připojení."
                  : "By creating a new game, you'll become its host. You'll be able to invite friends using the generated invite code."}
              </p>
              <p>
                {isCzechMode
                  ? "Každý hráč obdrží vlastní bingo kartu s náhodnými výzvami. Cílem je být první, kdo získá BINGO!"
                  : "Each player will receive their own bingo card with random challenges. The goal is to be the first to get BINGO!"}
              </p>
              <div className="mt-4 space-y-2">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  <span className="text-sm">
                    {isCzechMode ? "Pozvěte až 20 hráčů do jedné hry" : "Invite up to 20 players to a single game"}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <span className="text-sm">
                    {isCzechMode
                      ? "Sledujte postup ostatních hráčů v reálném čase"
                      : "Track other players' progress in real-time"}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
