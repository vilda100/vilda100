"use client"

import { Card, CardContent } from "@/components/ui/card"
import { useLanguage } from "@/lib/language-context"
import { Trophy, User } from "lucide-react"

interface PlayerListProps {
  players: any[]
  currentUserId: string
}

export default function PlayerList({ players, currentUserId }: PlayerListProps) {
  const { isCzechMode } = useLanguage()

  // Sort players by score (highest first)
  const sortedPlayers = [...players].sort((a, b) => b.score - a.score)

  return (
    <div className="space-y-4">
      {sortedPlayers.map((player) => (
        <Card key={player.id} className={`${player.user_id === currentUserId ? "border-primary" : ""}`}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-primary/10 p-2 rounded-full">
                  <User className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium">
                    {player.display_name || player.user?.username || "Player"}
                    {player.user_id === currentUserId && (
                      <span className="text-muted-foreground text-sm ml-2">({isCzechMode ? "vy" : "you"})</span>
                    )}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {player.score} {isCzechMode ? "splněných výzev" : "challenges completed"}
                  </p>
                </div>
              </div>
              {player.has_bingo && (
                <div className="flex items-center gap-1 text-yellow-500">
                  <Trophy className="h-5 w-5" />
                  <span className="font-bold">BINGO!</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}

      {players.length === 0 && (
        <div className="text-center py-12 bg-muted rounded-lg">
          <p className="text-muted-foreground">
            {isCzechMode ? "Zatím nejsou připojeni žádní hráči" : "No players connected yet"}
          </p>
        </div>
      )}
    </div>
  )
}
