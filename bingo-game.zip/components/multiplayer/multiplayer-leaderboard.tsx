"use client"

import { useRouter } from "next/navigation"
import Link from "next/link"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Trophy, Medal, Users, Star } from "lucide-react"
import LanguageToggle from "../language-toggle"

interface MultiplayerLeaderboardProps {
  topPlayersByBingos: any[]
  topPlayersByScore: any[]
  topPlayersByGames: any[]
  recentBingos: any[]
  userId: string
}

export default function MultiplayerLeaderboard({
  topPlayersByBingos,
  topPlayersByScore,
  topPlayersByGames,
  recentBingos,
  userId,
}: MultiplayerLeaderboardProps) {
  const router = useRouter()
  const { isCzechMode } = useLanguage()

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat(isCzechMode ? "cs-CZ" : "en-US", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{isCzechMode ? "Žebříček" : "Leaderboard"}</h1>
        <div className="flex gap-2">
          <LanguageToggle />
          <Button variant="outline" onClick={() => router.push("/multiplayer")} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            {isCzechMode ? "Zpět do lobby" : "Back to Lobby"}
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Tabs defaultValue="bingos">
            <TabsList className="mb-4">
              <TabsTrigger value="bingos">
                <Trophy className="h-4 w-4 mr-2" />
                {isCzechMode ? "Nejvíce BINGO" : "Most BINGOs"}
              </TabsTrigger>
              <TabsTrigger value="scores">
                <Star className="h-4 w-4 mr-2" />
                {isCzechMode ? "Nejvyšší skóre" : "Highest Scores"}
              </TabsTrigger>
              <TabsTrigger value="games">
                <Users className="h-4 w-4 mr-2" />
                {isCzechMode ? "Nejvíce her" : "Most Games"}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="bingos">
              <Card>
                <CardHeader>
                  <CardTitle>{isCzechMode ? "Hráči s nejvíce BINGO" : "Players with Most BINGOs"}</CardTitle>
                  <CardDescription>
                    {isCzechMode
                      ? "Žebříček hráčů podle počtu získaných BINGO"
                      : "Ranking of players by number of BINGOs achieved"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topPlayersByBingos.length > 0 ? (
                      topPlayersByBingos.map((player, index) => (
                        <div
                          key={player.user_id}
                          className={`flex items-center justify-between p-3 rounded-md border ${
                            player.user_id === userId ? "bg-primary/10" : ""
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-bold">
                              {index + 1}
                            </div>
                            <div>
                              <p className="font-medium">{player.display_name}</p>
                              <p className="text-sm text-muted-foreground">
                                {player.count} {isCzechMode ? "BINGO" : "BINGOs"}
                              </p>
                            </div>
                          </div>
                          {index < 3 && (
                            <Medal
                              className={`h-6 w-6 ${
                                index === 0 ? "text-yellow-500" : index === 1 ? "text-gray-400" : "text-amber-700"
                              }`}
                            />
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-12 bg-muted rounded-lg">
                        <p className="text-muted-foreground">
                          {isCzechMode ? "Zatím nejsou k dispozici žádná data" : "No data available yet"}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="scores">
              <Card>
                <CardHeader>
                  <CardTitle>{isCzechMode ? "Hráči s nejvyšším skóre" : "Players with Highest Scores"}</CardTitle>
                  <CardDescription>
                    {isCzechMode ? "Žebříček hráčů podle průměrného skóre" : "Ranking of players by average score"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topPlayersByScore.length > 0 ? (
                      topPlayersByScore.map((player, index) => (
                        <div
                          key={player.user_id}
                          className={`flex items-center justify-between p-3 rounded-md border ${
                            player.user_id === userId ? "bg-primary/10" : ""
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-bold">
                              {index + 1}
                            </div>
                            <div>
                              <p className="font-medium">{player.display_name}</p>
                              <p className="text-sm text-muted-foreground">
                                {Math.round(player.avg * 10) / 10} {isCzechMode ? "bodů v průměru" : "avg. points"}
                              </p>
                            </div>
                          </div>
                          {index < 3 && (
                            <Medal
                              className={`h-6 w-6 ${
                                index === 0 ? "text-yellow-500" : index === 1 ? "text-gray-400" : "text-amber-700"
                              }`}
                            />
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-12 bg-muted rounded-lg">
                        <p className="text-muted-foreground">
                          {isCzechMode ? "Zatím nejsou k dispozici žádná data" : "No data available yet"}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="games">
              <Card>
                <CardHeader>
                  <CardTitle>{isCzechMode ? "Hráči s nejvíce hrami" : "Players with Most Games"}</CardTitle>
                  <CardDescription>
                    {isCzechMode
                      ? "Žebříček hráčů podle počtu odehraných her"
                      : "Ranking of players by number of games played"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topPlayersByGames.length > 0 ? (
                      topPlayersByGames.map((player, index) => (
                        <div
                          key={player.user_id}
                          className={`flex items-center justify-between p-3 rounded-md border ${
                            player.user_id === userId ? "bg-primary/10" : ""
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-bold">
                              {index + 1}
                            </div>
                            <div>
                              <p className="font-medium">{player.display_name}</p>
                              <p className="text-sm text-muted-foreground">
                                {player.count} {isCzechMode ? "her" : "games"}
                              </p>
                            </div>
                          </div>
                          {index < 3 && (
                            <Medal
                              className={`h-6 w-6 ${
                                index === 0 ? "text-yellow-500" : index === 1 ? "text-gray-400" : "text-amber-700"
                              }`}
                            />
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-12 bg-muted rounded-lg">
                        <p className="text-muted-foreground">
                          {isCzechMode ? "Zatím nejsou k dispozici žádná data" : "No data available yet"}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "Nedávná BINGO" : "Recent BINGOs"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentBingos.length > 0 ? (
                  recentBingos.map((bingo) => (
                    <div key={bingo.id} className="flex items-start gap-3 p-3 rounded-md border">
                      <Trophy className="h-5 w-5 text-yellow-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">
                          {bingo.user?.username || "Player"}{" "}
                          <span className="font-normal text-muted-foreground">
                            {isCzechMode ? "získal(a) BINGO" : "got BINGO"}
                          </span>
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {isCzechMode ? "Ve hře" : "In"} {bingo.session?.name || "game"} •{" "}
                          {formatDate(bingo.created_at)}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">{isCzechMode ? "Zatím žádná BINGO" : "No BINGOs yet"}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "O žebříčku" : "About Leaderboard"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                {isCzechMode
                  ? "Žebříček zobrazuje nejlepší hráče v různých kategoriích napříč všemi multiplayerovými hrami."
                  : "The leaderboard shows the top players in various categories across all multiplayer games."}
              </p>
              <p>
                {isCzechMode
                  ? "Soutěžte s přáteli a snažte se dostat na vrchol žebříčku!"
                  : "Compete with friends and try to reach the top of the leaderboard!"}
              </p>
              <div className="pt-4">
                <Link href="/multiplayer">
                  <Button className="w-full">
                    <Users className="h-4 w-4 mr-2" />
                    {isCzechMode ? "Hrát multiplayer" : "Play Multiplayer"}
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
