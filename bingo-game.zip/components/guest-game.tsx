"use client"

import Link from "next/link"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { RefreshCw, LogIn, Trophy, Plus } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import BingoCard from "./bingo-card"
import GuestBanner from "./guest-banner"
import LanguageToggle from "./language-toggle"
import {
  generateGuestId,
  saveGuestId,
  getGuestId,
  getGuestCard,
  saveGuestCard,
  getGuestSubmissions,
} from "@/lib/guest-utils"
import type { Challenge } from "@/lib/types"

interface GuestGameProps {
  challenges: Challenge[]
}

export default function GuestGame({ challenges }: GuestGameProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { t, isCzechMode } = useLanguage()
  const [guestId, setGuestId] = useState<string | null>(null)
  const [cardData, setCardData] = useState<number[][]>([])
  const [completedChallenges, setCompletedChallenges] = useState<number[]>([])
  const [submissions, setSubmissions] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [hasWon, setHasWon] = useState(false)

  // Initialize guest session
  useEffect(() => {
    // Check if there's a guest ID in localStorage
    let id = getGuestId()

    // If not, generate a new one
    if (!id) {
      id = generateGuestId()
      saveGuestId(id)
    }

    setGuestId(id)

    // Load guest card if it exists
    const savedCard = getGuestCard()
    if (savedCard) {
      setCardData(savedCard.card_data || [])
      setCompletedChallenges(savedCard.completed_challenges || [])
    } else {
      generateNewCard()
    }

    // Load guest submissions
    setSubmissions(getGuestSubmissions())
  }, [])

  // Check for win conditions whenever completed challenges change
  useEffect(() => {
    if (cardData.length > 0 && completedChallenges.length >= 5) {
      checkForWin()
    }
  }, [completedChallenges, cardData])

  // Generate a new 5x5 bingo card with random challenges
  const generateNewCard = () => {
    if (challenges.length < 25) {
      toast({
        title: "Not enough challenges",
        description: "There must be at least 25 challenges in the database to generate a card.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      // Shuffle challenges and pick 25
      const shuffled = [...challenges].sort(() => 0.5 - Math.random())
      const selected = shuffled.slice(0, 25)

      // Create a 5x5 grid
      const newCardData: number[][] = Array(5)
        .fill(0)
        .map(() => Array(5).fill(0))

      // Fill the grid with challenge IDs
      selected.forEach((challenge, index) => {
        const row = Math.floor(index / 5)
        const col = index % 5
        newCardData[row][col] = challenge.id
      })

      // Save the card to localStorage
      const guestCard = {
        card_data: newCardData,
        completed_challenges: [], // Start with no completed spaces
        created_at: new Date().toISOString(),
      }

      saveGuestCard(guestCard)
      setCardData(newCardData)
      setCompletedChallenges([])

      toast({
        title: "New card generated",
        description: "Your bingo card has been created with new challenges!",
      })
    } catch (error: any) {
      toast({
        title: "Error generating card",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Check for winning patterns
  const checkForWin = () => {
    if (!cardData.length || hasWon) return

    // Check rows
    for (let row = 0; row < 5; row++) {
      if (cardData[row].every((challengeId) => completedChallenges.includes(challengeId))) {
        setHasWon(true)
        celebrateWin()
        return
      }
    }

    // Check columns
    for (let col = 0; col < 5; col++) {
      const column = cardData.map((row) => row[col])
      if (column.every((challengeId) => completedChallenges.includes(challengeId))) {
        setHasWon(true)
        celebrateWin()
        return
      }
    }

    // Check diagonals
    const diagonal1 = [cardData[0][0], cardData[1][1], cardData[2][2], cardData[3][3], cardData[4][4]]
    const diagonal2 = [cardData[0][4], cardData[1][3], cardData[2][2], cardData[3][1], cardData[4][0]]

    if (
      diagonal1.every((challengeId) => completedChallenges.includes(challengeId)) ||
      diagonal2.every((challengeId) => completedChallenges.includes(challengeId))
    ) {
      setHasWon(true)
      celebrateWin()
      return
    }
  }

  const celebrateWin = () => {
    toast({
      title: "BINGO!",
      description: t("youWon"),
      variant: "default",
    })
  }

  // Get challenge by ID
  const getChallengeById = (id: number) => {
    return challenges.find((challenge) => challenge.id === id)
  }

  // Check if a challenge has a submission
  const hasSubmission = (challengeId: number) => {
    return submissions.some(
      (sub) => sub.challenge_id === challengeId && (sub.status === "approved" || sub.status === "pending"),
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <GuestBanner />

      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{t("photoChallengeBingo")}</h1>
        <div className="flex gap-2">
          <LanguageToggle />
          <Button variant="outline" onClick={generateNewCard} disabled={loading} className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4" />
            {t("newCard")}
          </Button>
          <Link href="/auth/sign-up">
            <Button variant="default" className="flex items-center gap-2">
              <LogIn className="h-4 w-4" />
              {t("signUp")}
            </Button>
          </Link>
        </div>
      </header>

      {hasWon && (
        <div className="flex items-center justify-center p-4 mb-8 bg-green-100 dark:bg-green-900 rounded-lg animate-pulse">
          <Trophy className="h-8 w-8 text-yellow-500 mr-2" />
          <span className="text-2xl font-bold">{t("youWon")}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <BingoCard
            cardData={cardData}
            challenges={challenges}
            completedChallenges={completedChallenges}
            hasSubmission={hasSubmission}
          />
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">{t("howToPlay")}</h2>
              <ol className="space-y-2 list-decimal list-inside">
                {t("howToPlaySteps").map((step: string, index: number) => (
                  <li key={index}>{step}</li>
                ))}
              </ol>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">{t("guestModeLimitations")}</h2>
              <ul className="space-y-2 list-disc list-inside">
                {t("guestModeLimitationsItems").map((item: string, index: number) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
              <div className="mt-6">
                <Link href="/auth/sign-up">
                  <Button className="w-full">{t("createAccountToSaveProgress")}</Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">{isCzechMode ? "Vlastní výzvy" : "Custom Challenges"}</h2>
              <p className="mb-4 text-sm text-muted-foreground">
                {isCzechMode
                  ? "Pro vytváření vlastních výzev si prosím vytvořte účet."
                  : "Please create an account to create custom challenges."}
              </p>
              <Link href="/auth/sign-up">
                <Button className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  {t("signUp")}
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
