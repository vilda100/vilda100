"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "./supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, Download, Check, User } from "lucide-react"
import LanguageToggle from "./language-toggle"

interface ImportChallengeProps {
  sharedChallenge: any
  alreadyImported: boolean
  userId: string
}

export default function ImportChallenge({ sharedChallenge, alreadyImported, userId }: ImportChallengeProps) {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { t, isCzechMode } = useLanguage()
  const [isImporting, setIsImporting] = useState(false)
  const [imported, setImported] = useState(alreadyImported)

  const handleImportChallenge = async () => {
    if (imported) return

    setIsImporting(true)

    try {
      // First, create a custom challenge for the user
      const { data: customChallenge, error: customError } = await supabase
        .from("custom_challenges")
        .insert({
          user_id: userId,
          title: sharedChallenge.title,
          description: sharedChallenge.description,
          difficulty: sharedChallenge.difficulty,
          category: sharedChallenge.category,
        })
        .select()

      if (customError) throw customError

      // Then, record the import
      const { error: importError } = await supabase.from("imported_challenges").insert({
        user_id: userId,
        shared_challenge_id: sharedChallenge.id,
        custom_challenge_id: customChallenge[0].id,
      })

      if (importError) throw importError

      // Increment the import counter
      const { error: updateError } = await supabase
        .from("shared_challenges")
        .update({ times_imported: (sharedChallenge.times_imported || 0) + 1 })
        .eq("id", sharedChallenge.id)

      if (updateError) throw updateError

      setImported(true)
      toast({
        title: isCzechMode ? "Výzva importována" : "Challenge imported",
        description: isCzechMode
          ? "Výzva byla úspěšně přidána do vašich vlastních výzev"
          : "Challenge has been successfully added to your custom challenges",
      })
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba při importu" : "Error importing challenge",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsImporting(false)
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{isCzechMode ? "Importovat výzvu" : "Import Challenge"}</h1>
        <div className="flex gap-2">
          <LanguageToggle />
          <Button
            variant="outline"
            onClick={() => router.push("/custom-challenges")}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            {isCzechMode ? "Zpět na vlastní výzvy" : "Back to Custom Challenges"}
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>{sharedChallenge.title}</CardTitle>
              <CardDescription className="flex flex-wrap gap-2 mt-1">
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                  {sharedChallenge.difficulty}
                </span>
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary/10 text-secondary">
                  {sharedChallenge.category}
                </span>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">{sharedChallenge.description || (isCzechMode ? "Bez popisu" : "No description")}</p>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <User className="h-4 w-4" />
                <span>
                  {isCzechMode ? "Vytvořil(a)" : "Created by"}{" "}
                  <span className="font-medium">{sharedChallenge.profiles?.username || "Unknown"}</span>
                </span>
              </div>
              <div className="mt-4 text-sm text-muted-foreground">
                <span className="font-medium">{isCzechMode ? "Importováno" : "Imported"}:</span>{" "}
                {sharedChallenge.times_imported || 0} {isCzechMode ? "krát" : "times"}
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleImportChallenge} disabled={imported || isImporting} className="w-full">
                {imported ? (
                  <>
                    <Check className="h-4 w-4 mr-2" />
                    {isCzechMode ? "Výzva importována" : "Challenge Imported"}
                  </>
                ) : isImporting ? (
                  isCzechMode ? (
                    "Importování..."
                  ) : (
                    "Importing..."
                  )
                ) : (
                  <>
                    <Download className="h-4 w-4 mr-2" />
                    {isCzechMode ? "Importovat tuto výzvu" : "Import This Challenge"}
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{isCzechMode ? "O importování výzev" : "About Importing Challenges"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                {isCzechMode
                  ? "Importování výzev vám umožňuje přidat výzvy vytvořené jinými hráči do vaší hry."
                  : "Importing challenges allows you to add challenges created by other players to your game."}
              </p>
              <p>
                {isCzechMode
                  ? "Importované výzvy se stanou součástí vašich vlastních výzev a můžete je používat ve svých bingo kartách."
                  : "Imported challenges become part of your custom challenges and you can use them in your bingo cards."}
              </p>
              <p>
                {isCzechMode
                  ? "Po importu můžete výzvu upravit podle svých představ."
                  : "After importing, you can edit the challenge to suit your preferences."}
              </p>
              <div className="mt-4">
                <h3 className="font-medium mb-2">
                  {isCzechMode ? "Co se stane po importu:" : "What happens after importing:"}
                </h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>
                    {isCzechMode
                      ? "Výzva se přidá do vašich vlastních výzev"
                      : "The challenge is added to your custom challenges"}
                  </li>
                  <li>{isCzechMode ? "Můžete ji upravit nebo smazat" : "You can edit or delete it"}</li>
                  <li>
                    {isCzechMode ? "Bude se objevovat na vašich bingo kartách" : "It will appear on your bingo cards"}
                  </li>
                  <li>
                    {isCzechMode
                      ? "Tvůrce výzvy uvidí, že byla importována"
                      : "The creator will see that it was imported"}
                  </li>
                </ul>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => router.push("/custom-challenges")}>
                {isCzechMode ? "Zpět na vlastní výzvy" : "Back to Custom Challenges"}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
