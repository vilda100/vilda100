"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useSupabase } from "./supabase-provider"
import { useAuth } from "./auth-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { RefreshCw, LogOut, Trophy, Plus, Users } from "lucide-react"
import BingoCard from "./bingo-card"
import LanguageToggle from "./language-toggle"
import type { Challenge, BingoCardType, Submission } from "@/lib/types"

interface BingoGameProps {
  challenges: Challenge[]
  bingoCard?: BingoCardType
  submissions: Submission[]
  userId: string
}

export default function BingoGame({ challenges, bingoCard, submissions, userId }: BingoGameProps) {
  const { supabase } = useSupabase()
  const { signOut } = useAuth()
  const { t, isCzechMode } = useLanguage()
  const router = useRouter()
  const { toast } = useToast()
  const [cardData, setCardData] = useState<number[][]>([])
  const [completedChallenges, setCompletedChallenges] = useState<number[]>([])
  const [loading, setLoading] = useState(false)
  const [hasWon, setHasWon] = useState(false)

  // Initialize the game
  useEffect(() => {
    if (bingoCard) {
      setCardData(bingoCard.card_data as number[][])
      setCompletedChallenges(bingoCard.completed_challenges || [])
    } else {
      generateNewCard()
    }
  }, [bingoCard])

  // Check for win conditions whenever completed challenges change
  useEffect(() => {
    if (cardData.length > 0 && completedChallenges.length >= 5) {
      checkForWin()
    }
  }, [completedChallenges, cardData])

  // Generate a new 5x5 bingo card with random challenges
  const generateNewCard = async () => {
    if (challenges.length < 25) {
      toast({
        title: "Not enough challenges",
        description: "There must be at least 25 challenges in the database to generate a card.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      // Get custom challenges if available
      const { data: customChallenges } = await supabase.from("custom_challenges").select("*").eq("user_id", userId)

      // Combine standard and custom challenges
      const allChallenges = [...challenges]
      if (customChallenges && customChallenges.length > 0) {
        allChallenges.push(...customChallenges)
      }

      // Shuffle challenges and pick 25
      const shuffled = [...allChallenges].sort(() => 0.5 - Math.random())
      const selected = shuffled.slice(0, 25)

      // Create a 5x5 grid
      const newCardData: number[][] = Array(5)
        .fill(0)
        .map(() => Array(5).fill(0))

      // Fill the grid with challenge IDs
      selected.forEach((challenge, index) => {
        const row = Math.floor(index / 5)
        const col = index % 5
        newCardData[row][col] = challenge.id
      })

      // Save the card to the database
      const { error } = await supabase.from("bingo_cards").upsert({
        user_id: userId,
        card_data: newCardData,
        completed_challenges: [], // Start with no completed spaces
        updated_at: new Date().toISOString(),
      })

      if (error) throw error

      setCardData(newCardData)
      setCompletedChallenges([])

      toast({
        title: "New card generated",
        description: "Your bingo card has been created with new challenges!",
      })

      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error generating card",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Check for winning patterns
  const checkForWin = () => {
    if (!cardData.length || hasWon) return

    // Check rows
    for (let row = 0; row < 5; row++) {
      if (cardData[row].every((challengeId) => completedChallenges.includes(challengeId))) {
        setHasWon(true)
        celebrateWin()
        return
      }
    }

    // Check columns
    for (let col = 0; col < 5; col++) {
      const column = cardData.map((row) => row[col])
      if (column.every((challengeId) => completedChallenges.includes(challengeId))) {
        setHasWon(true)
        celebrateWin()
        return
      }
    }

    // Check diagonals
    const diagonal1 = [cardData[0][0], cardData[1][1], cardData[2][2], cardData[3][3], cardData[4][4]]
    const diagonal2 = [cardData[0][4], cardData[1][3], cardData[2][2], cardData[3][1], cardData[4][0]]

    if (
      diagonal1.every((challengeId) => completedChallenges.includes(challengeId)) ||
      diagonal2.every((challengeId) => completedChallenges.includes(challengeId))
    ) {
      setHasWon(true)
      celebrateWin()
      return
    }
  }

  const celebrateWin = () => {
    toast({
      title: "BINGO!",
      description: t("youWon"),
      variant: "default",
    })
  }

  // Get challenge by ID
  const getChallengeById = (id: number) => {
    return challenges.find((challenge) => challenge.id === id)
  }

  // Check if a challenge has a submission
  const hasSubmission = (challengeId: number) => {
    return submissions.some(
      (sub) => sub.challenge_id === challengeId && (sub.status === "approved" || sub.status === "pending"),
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{t("photoChallengeBingo")}</h1>
        <div className="flex gap-2">
          <LanguageToggle />
          <Link href="/multiplayer">
            <Button variant="outline" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              {isCzechMode ? "Multiplayer" : "Multiplayer"}
            </Button>
          </Link>
          <Link href="/custom-challenges">
            <Button variant="outline" className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              {isCzechMode ? "Vlastní výzvy" : "Custom Challenges"}
            </Button>
          </Link>
          <Button variant="outline" onClick={generateNewCard} disabled={loading} className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4" />
            {t("newCard")}
          </Button>
          <Button variant="outline" onClick={signOut} className="flex items-center gap-2">
            <LogOut className="h-4 w-4" />
            {t("signOut")}
          </Button>
        </div>
      </header>

      {hasWon && (
        <div className="flex items-center justify-center p-4 mb-8 bg-green-100 dark:bg-green-900 rounded-lg animate-pulse">
          <Trophy className="h-8 w-8 text-yellow-500 mr-2" />
          <span className="text-2xl font-bold">{t("youWon")}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <BingoCard
            cardData={cardData}
            challenges={challenges}
            completedChallenges={completedChallenges}
            hasSubmission={hasSubmission}
          />
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">{t("howToPlay")}</h2>
              <ol className="space-y-2 list-decimal list-inside">
                {t("howToPlaySteps").map((step: string, index: number) => (
                  <li key={index}>{step}</li>
                ))}
              </ol>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">{t("challengesCompleted")}</h2>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">{t("challengesCompleted")}</p>
                  <p className="text-2xl font-bold">{completedChallenges.length} / 25</p>
                </div>

                <div className="space-y-2">
                  <p className="font-medium">{t("recentSubmissions")}</p>
                  {submissions.length > 0 ? (
                    <ul className="space-y-2">
                      {submissions.slice(0, 5).map((submission) => {
                        const challenge = getChallengeById(submission.challenge_id)
                        return (
                          <li key={submission.id} className="text-sm">
                            <span
                              className={`inline-block w-2 h-2 rounded-full mr-2 ${
                                submission.status === "approved"
                                  ? "bg-green-500"
                                  : submission.status === "rejected"
                                    ? "bg-red-500"
                                    : "bg-yellow-500"
                              }`}
                            ></span>
                            {challenge?.title} - <span className="capitalize">{t(submission.status)}</span>
                          </li>
                        )
                      })}
                    </ul>
                  ) : (
                    <p className="text-sm text-muted-foreground">{t("noSubmissionsYet")}</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">{isCzechMode ? "Multiplayer" : "Multiplayer"}</h2>
              <p className="mb-4 text-sm text-muted-foreground">
                {isCzechMode
                  ? "Hrajte bingo s přáteli a soutěžte o to, kdo první získá BINGO!"
                  : "Play bingo with friends and compete to see who gets BINGO first!"}
              </p>
              <Link href="/multiplayer">
                <Button className="w-full">
                  <Users className="h-4 w-4 mr-2" />
                  {isCzechMode ? "Hrát multiplayer" : "Play Multiplayer"}
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
