import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase-server"
import ShareChallenges from "@/components/share-challenges"

export default async function SharePage() {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If user is not logged in, redirect to home
  if (!session) {
    redirect("/")
  }

  // Fetch user's custom challenges
  const { data: customChallenges } = await supabase
    .from("custom_challenges")
    .select("*")
    .eq("user_id", session.user.id)
    .order("created_at", { ascending: false })

  // Fetch user's shared challenges
  const { data: sharedChallenges } = await supabase
    .from("shared_challenges")
    .select("*")
    .eq("creator_id", session.user.id)
    .order("created_at", { ascending: false })

  return (
    <ShareChallenges
      customChallenges={customChallenges || []}
      sharedChallenges={sharedChallenges || []}
      userId={session.user.id}
    />
  )
}
