import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase-server"
import ChallengeDetail from "@/components/challenge-detail"
import GuestChallengeDetail from "@/components/guest-challenge-detail"

export default async function ChallengePage({ params }: { params: { id: string } }) {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Try to fetch challenge from standard challenges
  let { data: challenge } = await supabase.from("challenges").select("*").eq("id", params.id).single()

  // If not found, try to fetch from custom challenges
  if (!challenge && session) {
    const { data: customChallenge } = await supabase
      .from("custom_challenges")
      .select("*")
      .eq("id", params.id)
      .eq("user_id", session.user.id)
      .single()

    challenge = customChallenge
  }

  if (!challenge) {
    redirect("/game")
  }

  // For registered users, fetch their data
  if (session) {
    // Fetch user's submission for this challenge if it exists
    const { data: submission } = await supabase
      .from("submissions")
      .select("*")
      .eq("user_id", session.user.id)
      .eq("challenge_id", params.id)
      .single()

    return <ChallengeDetail challenge={challenge} submission={submission} userId={session.user.id} />
  }

  // For guest users, render the guest challenge component
  return <GuestChallengeDetail challenge={challenge} />
}
