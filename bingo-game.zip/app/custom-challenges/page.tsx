import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase-server"
import CustomChallengesManager from "@/components/custom-challenges-manager"

export default async function CustomChallengesPage() {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If user is not logged in, redirect to home
  if (!session) {
    redirect("/")
  }

  // Fetch user's custom challenges
  const { data: customChallenges } = await supabase
    .from("custom_challenges")
    .select("*")
    .eq("user_id", session.user.id)
    .order("created_at", { ascending: false })

  return <CustomChallengesManager initialChallenges={customChallenges || []} userId={session.user.id} />
}
