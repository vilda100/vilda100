import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase-server"
import ImportChallenge from "@/components/import-challenge"

export default async function ImportChallengePage({ params }: { params: { code: string } }) {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If user is not logged in, redirect to home
  if (!session) {
    redirect("/")
  }

  // Fetch the shared challenge by code
  const { data: sharedChallenge } = await supabase
    .from("shared_challenges")
    .select("*, profiles:creator_id(username)")
    .eq("share_code", params.code)
    .single()

  if (!sharedChallenge) {
    redirect("/custom-challenges?error=invalid-code")
  }

  // Check if the user has already imported this challenge
  const { data: existingImport } = await supabase
    .from("imported_challenges")
    .select("*")
    .eq("user_id", session.user.id)
    .eq("shared_challenge_id", sharedChallenge.id)
    .single()

  return (
    <ImportChallenge sharedChallenge={sharedChallenge} alreadyImported={!!existingImport} userId={session.user.id} />
  )
}
