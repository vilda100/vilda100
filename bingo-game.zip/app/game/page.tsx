import { createServerClient } from "@/lib/supabase-server"
import BingoGame from "@/components/bingo-game"
import GuestGame from "@/components/guest-game"

export default async function GamePage() {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Fetch challenges from the database (needed for both guest and registered users)
  const { data: challenges } = await supabase.from("challenges").select("*")

  if (!challenges || challenges.length === 0) {
    // Handle case where challenges couldn't be loaded
    return (
      <div className="container mx-auto py-8 px-4 text-center">
        <h1 className="text-3xl font-bold mb-4">Error Loading Game</h1>
        <p>Unable to load challenges. Please try again later.</p>
      </div>
    )
  }

  // For registered users, fetch their data
  if (session) {
    // Fetch user's bingo card if it exists
    const { data: bingoCard } = await supabase.from("bingo_cards").select("*").eq("user_id", session.user.id).single()

    // Fetch user's submissions
    const { data: submissions } = await supabase.from("submissions").select("*").eq("user_id", session.user.id)

    return (
      <BingoGame
        challenges={challenges}
        bingoCard={bingoCard}
        submissions={submissions || []}
        userId={session.user.id}
      />
    )
  }

  // For guest users, render the guest game component
  // The client component will check for guest ID in localStorage
  return <GuestGame challenges={challenges} />
}
