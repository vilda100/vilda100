import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase-server"
import MultiplayerLeaderboard from "@/components/multiplayer/multiplayer-leaderboard"

export default async function LeaderboardPage() {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If user is not logged in, redirect to home
  if (!session) {
    redirect("/")
  }

  // Fetch top players by number of bingos
  const { data: topPlayersByBingos } = await supabase
    .from("session_players")
    .select("user_id, display_name, count(*)")
    .eq("has_bingo", true)
    .group_by("user_id, display_name")
    .order("count", { ascending: false })
    .limit(10)

  // Fetch top players by average score
  const { data: topPlayersByScore } = await supabase
    .from("session_players")
    .select("user_id, display_name, avg(score)")
    .group_by("user_id, display_name")
    .order("avg", { ascending: false })
    .limit(10)

  // Fetch top players by games played
  const { data: topPlayersByGames } = await supabase
    .from("session_players")
    .select("user_id, display_name, count(*)")
    .group_by("user_id, display_name")
    .order("count", { ascending: false })
    .limit(10)

  // Fetch recent bingos
  const { data: recentBingos } = await supabase
    .from("session_events")
    .select("*, user:user_id(username), session:session_id(name)")
    .eq("event_type", "bingo")
    .order("created_at", { ascending: false })
    .limit(5)

  return (
    <MultiplayerLeaderboard
      topPlayersByBingos={topPlayersByBingos || []}
      topPlayersByScore={topPlayersByScore || []}
      topPlayersByGames={topPlayersByGames || []}
      recentBingos={recentBingos || []}
      userId={session.user.id}
    />
  )
}
