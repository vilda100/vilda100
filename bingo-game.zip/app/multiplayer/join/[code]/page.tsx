import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase-server"
import JoinGameSession from "@/components/multiplayer/join-game-session"

export default async function JoinGameSessionPage({ params }: { params: { code: string } }) {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If user is not logged in, redirect to home
  if (!session) {
    redirect("/")
  }

  // Fetch the game session by invite code
  const { data: gameSession } = await supabase
    .from("game_sessions")
    .select("*, creator:creator_id(username), players:session_players(user_id, display_name)")
    .eq("invite_code", params.code)
    .eq("is_active", true)
    .single()

  if (!gameSession) {
    redirect("/multiplayer?error=invalid-code")
  }

  // Check if user is already a participant
  const isParticipant = gameSession.players.some((player: any) => player.user_id === session.user.id)

  // Fetch user's profile
  const { data: profile } = await supabase.from("profiles").select("username").eq("id", session.user.id).single()

  return (
    <JoinGameSession
      gameSession={gameSession}
      userId={session.user.id}
      username={profile?.username || "Player"}
      isParticipant={isParticipant}
    />
  )
}
