import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase-server"
import MultiplayerLobby from "@/components/multiplayer/multiplayer-lobby"

export default async function MultiplayerPage() {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If user is not logged in, redirect to home
  if (!session) {
    redirect("/")
  }

  // Fetch active game sessions
  const { data: activeSessions } = await supabase
    .from("game_sessions")
    .select("*, creator:creator_id(username), players:session_players(user_id)")
    .eq("is_active", true)
    .order("created_at", { ascending: false })
    .limit(10)

  // Fetch sessions where the user is a participant
  const { data: userSessions } = await supabase
    .from("session_players")
    .select("session:session_id(*, creator:creator_id(username), players:session_players(user_id))")
    .eq("user_id", session.user.id)
    .order("joined_at", { ascending: false })

  // Fetch user's profile
  const { data: profile } = await supabase.from("profiles").select("username").eq("id", session.user.id).single()

  return (
    <MultiplayerLobby
      activeSessions={activeSessions || []}
      userSessions={userSessions?.map((item) => item.session) || []}
      userId={session.user.id}
      username={profile?.username || "Player"}
    />
  )
}
