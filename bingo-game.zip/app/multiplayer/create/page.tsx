import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase-server"
import CreateGameSession from "@/components/multiplayer/create-game-session"

export default async function CreateGameSessionPage() {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If user is not logged in, redirect to home
  if (!session) {
    redirect("/")
  }

  // Fetch user's profile
  const { data: profile } = await supabase.from("profiles").select("username").eq("id", session.user.id).single()

  return <CreateGameSession userId={session.user.id} username={profile?.username || "Player"} />
}
