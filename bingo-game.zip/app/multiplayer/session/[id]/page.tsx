import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase-server"
import GameSession from "@/components/multiplayer/game-session"

export default async function GameSessionPage({ params }: { params: { id: string } }) {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If user is not logged in, redirect to home
  if (!session) {
    redirect("/")
  }

  // Fetch the game session
  const { data: gameSession } = await supabase
    .from("game_sessions")
    .select("*, creator:creator_id(username)")
    .eq("id", params.id)
    .single()

  if (!gameSession) {
    redirect("/multiplayer?error=session-not-found")
  }

  // Check if user is a participant
  const { data: playerData } = await supabase
    .from("session_players")
    .select("*")
    .eq("session_id", params.id)
    .eq("user_id", session.user.id)
    .single()

  if (!playerData) {
    redirect(`/multiplayer/join/${gameSession.invite_code}`)
  }

  // Fetch all players in the session
  const { data: players } = await supabase
    .from("session_players")
    .select("*, user:user_id(username)")
    .eq("session_id", params.id)
    .order("score", { ascending: false })

  // Fetch challenges for the game
  const { data: challenges } = await supabase.from("challenges").select("*")

  // Fetch user's bingo card if it exists
  const { data: bingoCard } = await supabase.from("bingo_cards").select("*").eq("id", playerData.card_id).single()

  // Fetch user's submissions
  const { data: submissions } = await supabase.from("submissions").select("*").eq("user_id", session.user.id)

  return (
    <GameSession
      gameSession={gameSession}
      player={playerData}
      players={players || []}
      challenges={challenges || []}
      bingoCard={bingoCard}
      submissions={submissions || []}
      userId={session.user.id}
    />
  )
}
