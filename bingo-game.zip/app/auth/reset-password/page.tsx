"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"
import { Eye, EyeOff } from "lucide-react"
import LanguageToggle from "@/components/language-toggle"

export default function ResetPassword() {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { isCzechMode } = useLanguage()

  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [passwordStrength, setPasswordStrength] = useState(0)
  const [errors, setErrors] = useState<{
    password?: string
    confirmPassword?: string
  }>({})

  // Calculate password strength
  useEffect(() => {
    if (!password) {
      setPasswordStrength(0)
      return
    }

    let strength = 0

    // Length check
    if (password.length >= 8) strength += 25

    // Contains number
    if (/\d/.test(password)) strength += 25

    // Contains lowercase
    if (/[a-z]/.test(password)) strength += 25

    // Contains uppercase or special char
    if (/[A-Z]/.test(password) || /[^A-Za-z0-9]/.test(password)) strength += 25

    setPasswordStrength(strength)
  }, [password])

  const validateForm = () => {
    const newErrors: {
      password?: string
      confirmPassword?: string
    } = {}

    // Password validation
    if (!password) {
      newErrors.password = isCzechMode ? "Heslo je povinné" : "Password is required"
    } else if (password.length < 8) {
      newErrors.password = isCzechMode ? "Heslo musí mít alespoň 8 znaků" : "Password must be at least 8 characters"
    }

    // Confirm password validation
    if (!confirmPassword) {
      newErrors.confirmPassword = isCzechMode ? "Potvrzení hesla je povinné" : "Confirm password is required"
    } else if (password !== confirmPassword) {
      newErrors.confirmPassword = isCzechMode ? "Hesla se neshodují" : "Passwords do not match"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setLoading(true)

    try {
      const { error } = await supabase.auth.updateUser({
        password,
      })

      if (error) throw error

      toast({
        title: isCzechMode ? "Heslo obnoveno" : "Password Reset",
        description: isCzechMode ? "Vaše heslo bylo úspěšně obnoveno" : "Your password has been successfully reset",
      })

      router.push("/auth/sign-in")
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba" : "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const getPasswordStrengthText = () => {
    if (passwordStrength === 0) return isCzechMode ? "Velmi slabé" : "Very weak"
    if (passwordStrength <= 25) return isCzechMode ? "Slabé" : "Weak"
    if (passwordStrength <= 50) return isCzechMode ? "Střední" : "Medium"
    if (passwordStrength <= 75) return isCzechMode ? "Silné" : "Strong"
    return isCzechMode ? "Velmi silné" : "Very strong"
  }

  const getPasswordStrengthColor = () => {
    if (passwordStrength <= 25) return "bg-red-500"
    if (passwordStrength <= 50) return "bg-orange-500"
    if (passwordStrength <= 75) return "bg-yellow-500"
    return "bg-green-500"
  }

  return (
    <div className="flex justify-center items-center min-h-screen p-4 bg-muted/40">
      <div className="w-full max-w-md">
        <div className="flex justify-end mb-4">
          <LanguageToggle />
        </div>

        <Card className="w-full">
          <CardHeader>
            <CardTitle>{isCzechMode ? "Nastavení nového hesla" : "Set New Password"}</CardTitle>
            <CardDescription>
              {isCzechMode ? "Vytvořte si nové heslo pro váš účet" : "Create a new password for your account"}
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleResetPassword}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">{isCzechMode ? "Nové heslo" : "New Password"}</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className={errors.password ? "border-red-500 pr-10" : ""}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <Eye className="h-5 w-5 text-muted-foreground" />
                    )}
                  </button>
                </div>
                {errors.password && <p className="text-sm text-red-500">{errors.password}</p>}

                {password && (
                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">{getPasswordStrengthText()}</span>
                      <span className="text-xs text-muted-foreground">{passwordStrength}%</span>
                    </div>
                    <Progress value={passwordStrength} className={getPasswordStrengthColor()} />
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">{isCzechMode ? "Potvrzení hesla" : "Confirm Password"}</Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className={errors.confirmPassword ? "border-red-500 pr-10" : ""}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2"
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <Eye className="h-5 w-5 text-muted-foreground" />
                    )}
                  </button>
                </div>
                {errors.confirmPassword && <p className="text-sm text-red-500">{errors.confirmPassword}</p>}
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading
                  ? isCzechMode
                    ? "Ukládání..."
                    : "Saving..."
                  : isCzechMode
                    ? "Nastavit nové heslo"
                    : "Set New Password"}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  )
}
