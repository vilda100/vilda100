"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useSupabase } from "@/components/supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { Progress } from "@/components/ui/progress"
import { Eye, EyeOff, Github, AlertCircle } from "lucide-react"
import { FcGoogle } from "react-icons/fc"
import { FaFacebook, FaTwitter } from "react-icons/fa"
import LanguageToggle from "@/components/language-toggle"

export default function SignUp() {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { t, isCzechMode } = useLanguage()

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [username, setUsername] = useState("")
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [acceptTerms, setAcceptTerms] = useState(false)
  const [passwordStrength, setPasswordStrength] = useState(0)
  const [errors, setErrors] = useState<{
    email?: string
    password?: string
    username?: string
    terms?: string
  }>({})

  // Calculate password strength
  useEffect(() => {
    if (!password) {
      setPasswordStrength(0)
      return
    }

    let strength = 0

    // Length check
    if (password.length >= 8) strength += 25

    // Contains number
    if (/\d/.test(password)) strength += 25

    // Contains lowercase
    if (/[a-z]/.test(password)) strength += 25

    // Contains uppercase or special char
    if (/[A-Z]/.test(password) || /[^A-Za-z0-9]/.test(password)) strength += 25

    setPasswordStrength(strength)
  }, [password])

  const validateForm = () => {
    const newErrors: {
      email?: string
      password?: string
      username?: string
      terms?: string
    } = {}

    // Email validation
    if (!email) {
      newErrors.email = isCzechMode ? "Email je povinný" : "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = isCzechMode ? "Neplatný formát emailu" : "Invalid email format"
    }

    // Password validation
    if (!password) {
      newErrors.password = isCzechMode ? "Heslo je povinné" : "Password is required"
    } else if (password.length < 8) {
      newErrors.password = isCzechMode ? "Heslo musí mít alespoň 8 znaků" : "Password must be at least 8 characters"
    }

    // Username validation
    if (!username) {
      newErrors.username = isCzechMode ? "Uživatelské jméno je povinné" : "Username is required"
    } else if (username.length < 3) {
      newErrors.username = isCzechMode
        ? "Uživatelské jméno musí mít alespoň 3 znaky"
        : "Username must be at least 3 characters"
    }

    // Terms validation
    if (!acceptTerms) {
      newErrors.terms = isCzechMode ? "Musíte souhlasit s podmínkami" : "You must accept the terms"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setLoading(true)

    try {
      // Create the user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          // This option skips the email verification step
          emailRedirectTo: undefined,
          data: {
            username,
          },
        },
      })

      if (authError) throw authError

      if (authData.user) {
        // Create a profile for the user
        const { error: profileError } = await supabase.from("profiles").insert([{ id: authData.user.id, username }])

        if (profileError) throw profileError

        // Sign in the user immediately after registration
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        })

        if (signInError) throw signInError

        toast({
          title: isCzechMode ? "Účet vytvořen" : "Account created",
          description: isCzechMode
            ? "Úspěšně jste se zaregistrovali a jste přihlášeni!"
            : "You have successfully signed up and are now logged in!",
        })

        router.push("/game")
        router.refresh()
      }
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba při registraci" : "Error signing up",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSocialSignUp = async (provider: "github" | "google" | "facebook" | "twitter") => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) throw error
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba při přihlášení" : "Error signing in",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const getPasswordStrengthText = () => {
    if (passwordStrength === 0) return isCzechMode ? "Velmi slabé" : "Very weak"
    if (passwordStrength <= 25) return isCzechMode ? "Slabé" : "Weak"
    if (passwordStrength <= 50) return isCzechMode ? "Střední" : "Medium"
    if (passwordStrength <= 75) return isCzechMode ? "Silné" : "Strong"
    return isCzechMode ? "Velmi silné" : "Very strong"
  }

  const getPasswordStrengthColor = () => {
    if (passwordStrength <= 25) return "bg-red-500"
    if (passwordStrength <= 50) return "bg-orange-500"
    if (passwordStrength <= 75) return "bg-yellow-500"
    return "bg-green-500"
  }

  return (
    <div className="flex justify-center items-center min-h-screen p-4 bg-muted/40">
      <div className="w-full max-w-md">
        <div className="flex justify-end mb-4">
          <LanguageToggle />
        </div>

        <Card className="w-full">
          <CardHeader>
            <CardTitle>{isCzechMode ? "Registrace" : "Sign Up"}</CardTitle>
            <CardDescription>
              {isCzechMode
                ? "Vytvořte si účet pro hraní Photo Challenge Bingo"
                : "Create an account to play Photo Challenge Bingo"}
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSignUp}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">{isCzechMode ? "Email" : "Email"}</Label>
                <div className="relative">
                  <Input
                    id="email"
                    type="email"
                    placeholder={isCzechMode ? "vas.email@priklad.cz" : "your.email@example.com"}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={errors.email ? "border-red-500 pr-10" : ""}
                  />
                  {errors.email && (
                    <AlertCircle className="h-5 w-5 text-red-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                  )}
                </div>
                {errors.email && <p className="text-sm text-red-500">{errors.email}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="username">{isCzechMode ? "Uživatelské jméno" : "Username"}</Label>
                <div className="relative">
                  <Input
                    id="username"
                    type="text"
                    placeholder={isCzechMode ? "superhrac123" : "cooluser123"}
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className={errors.username ? "border-red-500 pr-10" : ""}
                  />
                  {errors.username && (
                    <AlertCircle className="h-5 w-5 text-red-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                  )}
                </div>
                {errors.username && <p className="text-sm text-red-500">{errors.username}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">{isCzechMode ? "Heslo" : "Password"}</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className={errors.password ? "border-red-500 pr-10" : ""}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <Eye className="h-5 w-5 text-muted-foreground" />
                    )}
                  </button>
                </div>
                {errors.password && <p className="text-sm text-red-500">{errors.password}</p>}

                {password && (
                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">{getPasswordStrengthText()}</span>
                      <span className="text-xs text-muted-foreground">{passwordStrength}%</span>
                    </div>
                    <Progress value={passwordStrength} className={getPasswordStrengthColor()} />
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="terms"
                  checked={acceptTerms}
                  onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
                />
                <label
                  htmlFor="terms"
                  className={`text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 ${
                    errors.terms ? "text-red-500" : ""
                  }`}
                >
                  {isCzechMode
                    ? "Souhlasím s podmínkami použití a zásadami ochrany osobních údajů"
                    : "I agree to the terms of service and privacy policy"}
                </label>
              </div>
              {errors.terms && <p className="text-sm text-red-500">{errors.terms}</p>}
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button type="submit" className="w-full" disabled={loading}>
                {loading
                  ? isCzechMode
                    ? "Vytváření účtu..."
                    : "Creating account..."
                  : isCzechMode
                    ? "Registrovat se"
                    : "Sign Up"}
              </Button>

              <div className="relative w-full">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">{isCzechMode ? "nebo" : "or"}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Button type="button" variant="outline" className="w-full" onClick={() => handleSocialSignUp("github")}>
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                </Button>
                <Button type="button" variant="outline" className="w-full" onClick={() => handleSocialSignUp("google")}>
                  <FcGoogle className="mr-2 h-4 w-4" />
                  Google
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => handleSocialSignUp("facebook")}
                >
                  <FaFacebook className="mr-2 h-4 w-4 text-blue-600" />
                  Facebook
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => handleSocialSignUp("twitter")}
                >
                  <FaTwitter className="mr-2 h-4 w-4 text-blue-400" />
                  Twitter
                </Button>
              </div>

              <p className="text-sm text-center">
                {isCzechMode ? "Již máte účet?" : "Already have an account?"}{" "}
                <Link href="/auth/sign-in" className="text-primary hover:underline">
                  {isCzechMode ? "Přihlásit se" : "Sign in"}
                </Link>
              </p>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  )
}
