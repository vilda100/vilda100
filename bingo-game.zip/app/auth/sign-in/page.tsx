"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useSupabase } from "@/components/supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { Eye, EyeOff, Github, AlertCircle } from "lucide-react"
import { FcGoogle } from "react-icons/fc"
import { FaFacebook, FaTwitter } from "react-icons/fa"
import LanguageToggle from "@/components/language-toggle"

export default function SignIn() {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { isCzechMode } = useLanguage()

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(false)
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [errors, setErrors] = useState<{
    email?: string
    password?: string
  }>({})

  const validateForm = () => {
    const newErrors: {
      email?: string
      password?: string
    } = {}

    // Email validation
    if (!email) {
      newErrors.email = isCzechMode ? "Email je povinný" : "Email is required"
    }

    // Password validation
    if (!password) {
      newErrors.password = isCzechMode ? "Heslo je povinné" : "Password is required"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setLoading(true)

    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) throw error

      router.push("/game")
      router.refresh()
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba při přihlášení" : "Error signing in",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSocialSignIn = async (provider: "github" | "google" | "facebook" | "twitter") => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) throw error
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba při přihlášení" : "Error signing in",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  return (
    <div className="flex justify-center items-center min-h-screen p-4 bg-muted/40">
      <div className="w-full max-w-md">
        <div className="flex justify-end mb-4">
          <LanguageToggle />
        </div>

        <Card className="w-full">
          <CardHeader>
            <CardTitle>{isCzechMode ? "Přihlášení" : "Sign In"}</CardTitle>
            <CardDescription>
              {isCzechMode
                ? "Přihlaste se ke svému účtu Photo Challenge Bingo"
                : "Sign in to your Photo Challenge Bingo account"}
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSignIn}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">{isCzechMode ? "Email" : "Email"}</Label>
                <div className="relative">
                  <Input
                    id="email"
                    type="email"
                    placeholder={isCzechMode ? "vas.email@priklad.cz" : "your.email@example.com"}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={errors.email ? "border-red-500 pr-10" : ""}
                  />
                  {errors.email && (
                    <AlertCircle className="h-5 w-5 text-red-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                  )}
                </div>
                {errors.email && <p className="text-sm text-red-500">{errors.email}</p>}
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="password">{isCzechMode ? "Heslo" : "Password"}</Label>
                  <Link href="/auth/forgot-password" className="text-xs text-primary hover:underline">
                    {isCzechMode ? "Zapomenuté heslo?" : "Forgot password?"}
                  </Link>
                </div>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className={errors.password ? "border-red-500 pr-10" : ""}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <Eye className="h-5 w-5 text-muted-foreground" />
                    )}
                  </button>
                </div>
                {errors.password && <p className="text-sm text-red-500">{errors.password}</p>}
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                />
                <label
                  htmlFor="remember"
                  className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  {isCzechMode ? "Zapamatovat si mě" : "Remember me"}
                </label>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button type="submit" className="w-full" disabled={loading}>
                {loading
                  ? isCzechMode
                    ? "Přihlašování..."
                    : "Signing in..."
                  : isCzechMode
                    ? "Přihlásit se"
                    : "Sign In"}
              </Button>

              <div className="relative w-full">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">{isCzechMode ? "nebo" : "or"}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Button type="button" variant="outline" className="w-full" onClick={() => handleSocialSignIn("github")}>
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                </Button>
                <Button type="button" variant="outline" className="w-full" onClick={() => handleSocialSignIn("google")}>
                  <FcGoogle className="mr-2 h-4 w-4" />
                  Google
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => handleSocialSignIn("facebook")}
                >
                  <FaFacebook className="mr-2 h-4 w-4 text-blue-600" />
                  Facebook
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => handleSocialSignIn("twitter")}
                >
                  <FaTwitter className="mr-2 h-4 w-4 text-blue-400" />
                  Twitter
                </Button>
              </div>

              <p className="text-sm text-center">
                {isCzechMode ? "Nemáte účet?" : "Don't have an account?"}{" "}
                <Link href="/auth/sign-up" className="text-primary hover:underline">
                  {isCzechMode ? "Registrovat se" : "Sign up"}
                </Link>
              </p>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  )
}
