"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useSupabase } from "@/components/supabase-provider"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { AlertCircle, ArrowLeft, CheckCircle } from "lucide-react"
import LanguageToggle from "@/components/language-toggle"

export default function ForgotPassword() {
  const { supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const { isCzechMode } = useLanguage()

  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email) {
      setError(isCzechMode ? "Email je povinný" : "Email is required")
      return
    }

    if (!/\S+@\S+\.\S+/.test(email)) {
      setError(isCzechMode ? "Neplatný formát emailu" : "Invalid email format")
      return
    }

    setError(null)
    setLoading(true)

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/reset-password`,
      })

      if (error) throw error

      setSubmitted(true)
      toast({
        title: isCzechMode ? "Email odeslán" : "Email sent",
        description: isCzechMode
          ? "Pokyny k obnovení hesla byly odeslány na váš email"
          : "Password reset instructions have been sent to your email",
      })
    } catch (error: any) {
      toast({
        title: isCzechMode ? "Chyba" : "Error",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex justify-center items-center min-h-screen p-4 bg-muted/40">
      <div className="w-full max-w-md">
        <div className="flex justify-end mb-4">
          <LanguageToggle />
        </div>

        <Card className="w-full">
          <CardHeader>
            <CardTitle>{isCzechMode ? "Obnovení hesla" : "Reset Password"}</CardTitle>
            <CardDescription>
              {isCzechMode
                ? "Zadejte svůj email a my vám pošleme pokyny k obnovení hesla"
                : "Enter your email and we'll send you instructions to reset your password"}
            </CardDescription>
          </CardHeader>

          {submitted ? (
            <CardContent className="space-y-4">
              <div className="flex flex-col items-center justify-center py-6 text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{isCzechMode ? "Email odeslán" : "Email Sent"}</h3>
                <p className="text-muted-foreground mb-4">
                  {isCzechMode
                    ? `Pokyny k obnovení hesla byly odeslány na ${email}`
                    : `Password reset instructions have been sent to ${email}`}
                </p>
                <p className="text-sm text-muted-foreground">
                  {isCzechMode
                    ? "Pokud email neobdržíte do několika minut, zkontrolujte složku spam"
                    : "If you don't receive an email within a few minutes, check your spam folder"}
                </p>
              </div>
            </CardContent>
          ) : (
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">{isCzechMode ? "Email" : "Email"}</Label>
                  <div className="relative">
                    <Input
                      id="email"
                      type="email"
                      placeholder={isCzechMode ? "vas.email@priklad.cz" : "your.email@example.com"}
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={error ? "border-red-500 pr-10" : ""}
                    />
                    {error && (
                      <AlertCircle className="h-5 w-5 text-red-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                    )}
                  </div>
                  {error && <p className="text-sm text-red-500">{error}</p>}
                </div>
              </CardContent>
              <CardFooter className="flex flex-col space-y-4">
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading
                    ? isCzechMode
                      ? "Odesílání..."
                      : "Sending..."
                    : isCzechMode
                      ? "Odeslat pokyny"
                      : "Send Instructions"}
                </Button>

                <Link href="/auth/sign-in" className="w-full">
                  <Button variant="outline" className="w-full" type="button">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    {isCzechMode ? "Zpět na přihlášení" : "Back to Sign In"}
                  </Button>
                </Link>
              </CardFooter>
            </form>
          )}
        </Card>
      </div>
    </div>
  )
}
