import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")

  if (code) {
    const cookieStore = cookies()
    const supabase = createRouteHandlerClient({ cookies: () => cookieStore })

    // Exchange the code for a session
    await supabase.auth.exchangeCodeForSession(code)

    // Create a profile for the user if it doesn't exist
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (user) {
      // Check if profile exists
      const { data: existingProfile } = await supabase.from("profiles").select().eq("id", user.id).single()

      // If no profile exists, create one
      if (!existingProfile) {
        // Extract username from provider data
        let username = ""

        // Try to get a username from the provider metadata
        if (user.user_metadata) {
          // Different providers store usernames in different fields
          username =
            user.user_metadata.user_name || // GitHub
            user.user_metadata.name || // Google
            user.user_metadata.full_name || // Facebook
            user.user_metadata.preferred_username || // Twitter
            user.user_metadata.email?.split("@")[0] || // Fallback to email username
            `user_${Math.floor(Math.random() * 10000)}` // Random fallback
        }

        // Create profile
        await supabase.from("profiles").insert({
          id: user.id,
          username,
          avatar_url: user.user_metadata?.avatar_url || null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
      }
    }
  }

  // URL to redirect to after sign in process completes
  return NextResponse.redirect(requestUrl.origin + "/game")
}
